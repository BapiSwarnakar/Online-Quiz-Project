<?php
define('EMAIL','example@gmail.com');
define('PASS', 'password');

?>