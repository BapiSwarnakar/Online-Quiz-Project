<?php
//include_once("class/class.php");
$conn = mysqli_connect("localhost","root","","online_quiz");
if($conn)
{
	echo "Success";
}
if($_GET['SignUp']){
    //$signup = new Connect;

    $name = $_GET['name'];
    $email = $_GET['email'];
    $mobile = $_GET['mobile'];
    $password = $_GET['password'];
	$query = "INSERT INTO `signup_table`(`user_id`, `name`, `email`, `mobile`, `password`, `photo`) VALUES (null,'$name','$email','$mobile','$password','1')";
	$result = mysqli_query($conn,$query);
	
   header("location: index.php");

}

?>