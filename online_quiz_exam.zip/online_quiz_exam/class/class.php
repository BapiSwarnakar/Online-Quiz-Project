<?php
class Examination 
{
	var $host;
	var $username;
	var $password;
	var $database;
	var $conn;
	var $home_page;
	var $query;
	var $data;
	var $statement;
	var $filedata;
	

	
	 public function __construct()
	   {
		
		$this->host = "localhost";
		$this->username ="root";
		$this->password="";
		$this->dbname="online_examination";
		$this->home_page="http://localhost/online_quiz_exam/";

	  $this->conn= new PDO("mysql:host=$this->host;dbname=$this->dbname","$this->username","$this->password");
	  	if(!$this->conn)
		{
			
			echo "Connected eror";
			    
		}
		session_start();

    }

    public function execute_query(){
    	$this->statement = $this->conn->prepare($this->query);
    	$this->statement->execute($this->data);
    }
    public function total_row(){

    	$this->execute_query();
    	return $this->statement->rowCount();
    }

    public function send_email($reciever_email,$subject,$body)
    {
    	$mail = new PHPMailer;
    	$mail->isSMTP();
    	$mail->Host = 'smtp.gmail.com';
    	$mail->Post = '587';
    	$mail->SMTPAuth = true;
    	$mail->Username ='swarnakarr34@gmail.com';
    	$mail->Password = 'Codewithbapi';
    	$mail->SMTPSecure ='';
    	$mail->From ='';
    	$mail->FromName ='';
    	$mail->AddAddress($reciever_email,'');
    	$mail->isHTML(true);
    	$mail->Subject = $subject;
    	$mail->Body=$body;
    	$mail->Send();

    }
}