<?php
include_once ("header.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>
<?php
include_once("footer.php");
?>