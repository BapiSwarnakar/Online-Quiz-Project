<?php include_once("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" >
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.js"></script>
<!--     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->




    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/guillaumepotier/Parsley.js@2.9.1/dist/parsley.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../style/style.css" />
     <style> 
      input.parsley-success,
       select.parsley-success,
       textarea.parsley-success {
         color: #468847;
         background-color: #DFF0D8;
         border: 1px solid #D6E9C6;
       }

       input.parsley-error,
       select.parsley-error,
       textarea.parsley-error {
         color: #B94A48;
         background-color: #F2DEDE;
         border: 1px solid #EED3D7;
       }

       .parsley-errors-list {
         margin: 2px 0 3px;
         padding: 0;
         list-style-type: none;
         font-size: 0.9em;
         line-height: 0.9em;
         opacity: 0;

         transition: all .3s ease-in;
         -o-transition: all .3s ease-in;
         -moz-transition: all .3s ease-in;
         -webkit-transition: all .3s ease-in;
       }

       .parsley-errors-list.filled {
         opacity: 1;
       }
       
       .parsley-type,
       .parsley-required,
       .parsley-equalto,
       .parsley-pattern,
       .parsley-urlstrict,
       .parsley-length,
       .parsley-checkemail{
        color:#ff0000;
       }
    </style>
</head>
<body>
<div class="container col-lg-4 bg-light " style="margin-top: 8%; padding: 10px;">
	<h3 class="text-danger text-center">ADMIN REGISTER</h3>
	<form method="post" id="admin_register_form">
		<div class="form-group">
			<label>Email :</label>
			<input type="text" class="form-control" placeholder="Email.." id="admin_email_address" data-parsley-type="email" data-parsley-trigger="focusout" data-parsley-checkemail data-parsley-checkemail-message="Email Address already Exists"/>
		</div>
		<div class="form-group">
			<label>Password :</label>
			<input type="text" class="form-control" placeholder="Password.." id="admin_password">
		</div>
		<div class="form-group">
			<label>Confirm Password :</label>
			<input type="Password" class="form-control"  placeholder="Confirm Password.." id="confirm_admin_password">
		</div>
		<div class="form-group">
			<input type="hidden" name="page" value="register" />
			<input type="hidden" name="action" value="register" />
		</div>
		<input type="submit" name="admin_register" id="admin_register" class="btn btn-info" value="Register">
	<div align="center">
		<a href="admin_login.php">Login</a>
	</div>
  </form>
</div>

</body>
</html>
<script>
  $(document).ready(function(){

    window.ParsleyValidator.addValidator('checkemail', {
      validateString: function(value)
      {
        return $.ajax({
          url:'ajax_action.php',
          method:"POST",
          data:{page:'register',action:'check_email',email:value},
          dataType:"json",
          success:function(data)
          {
            return true;
          }
        });
      }
    });
    $('#admin_register_form').parsley();

    $('#admin_register').click(function(){

       $('#admin_email_address').attr('required', 'required');
       $('#admin_password').attr('required', 'required');
       $('#confirm_admin_password').attr('required', 'required');
       $('#confirm_admin_password').attr('data-parsley-equalto','#admin_password');
       if($('#admin_register_form').validate())
       {
        alert("success");
       }
    });
    
  });
</script>
