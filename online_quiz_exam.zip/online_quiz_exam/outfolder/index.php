<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container col-lg-4 bg-light " style="margin-top: 8%; padding: 10px;">
	<h3 class="text-danger text-center">ADMIN REGISTER</h3>
	<form method="post" id="admin_register_form">
		<div class="form-group">
			<label>Email :</label>
			<input type="text" class="form-control" autocomplete="off" placeholder="Email.." id="admin_email_address" />
			<p id="emailcheck"></p>
		</div>
		<div class="form-group">
			<label>Password :</label>
			<input type="text" class="form-control" autocomplete="off" placeholder="Password.." id="admin_password">
			<p id="passcheck"></p>
		</div>
		<div class="form-group">
			<label>Confirm Password :</label>
			<input type="Password" class="form-control" autocomplete="off"  placeholder="Confirm Password.." id="confirm_admin_password">
			<p id="conpasscheck">This field required</p>
		</div>
		<input type="submit" name="admin_register" id="admin_register" class="btn btn-info" value="Register">
	<div align="center">
		<a href="admin_login.php">Login</a>
	</div>
  </form>
</div>
</body>
<script type="text/javascript">
	$(document).ready(function(){
		$('#emailcheck').hide();
		$('#passcheck').hide();
		$('#conpasscheck').hide();

		var emailcheck_err = true;
		var passcheck_err = true;
		var conpasscheck_err = true;

		$('#admin_email_address').keyup(function(){
			emailcheck_function();
		})
		function emailcheck_function(){
			var email_val = $('#admin_email_address').val();
			if(email_val.length=='')
			{
				$('#emailcheck').show();
				$('#emailcheck').html("**This field is required !");
				$('#emailcheck').focus();
				$('#emailcheck').css("color","red");
				emailcheck_err = false;
				return false;
			}else{
				$('#emailcheck').hide();
			}
			if((email_val.length)<3 || (email_val.length)>10  )
			{
				$('#emailcheck').show();
				$('#emailcheck').html("**email length must be between 3 to 10 !");
				$('#emailcheck').focus();
				$('#emailcheck').css("color","red");
				emailcheck_err = false;
				return false;
			}else{
				$('#emailcheck').hide();
			}
		}


		$('#admin_password').keyup(function(){
			passwordcheck_function();
		})
		function passwordcheck_function(){
			var password_val = $('#admin_password').val();
			if(password_val.length=='')
			{
				$('#passcheck').show();
				$('#passcheck').html("**This field is required !");
				$('#passcheck').focus();
				$('#passcheck').css("color","red");
				passcheck_err = false;
				return false;
			}else{
				$('#passcheck').hide();
			}
			if((password_val.length)<5 || (password_val.length)>8  )
			{
				$('#passcheck').show();
				$('#passcheck').html("**Password length must be between 5 to 8 !");
				$('#passcheck').focus();
				$('#passcheck').css("color","red");
				passcheck_err = false;
				return false;
			}else{
				$('#passcheck').hide();
			}
		}


		$('#confirm_admin_password').keyup(function(){
			confirmpasswordcheck_function();
		})
		function confirmpasswordcheck_function(){
			var con_password = $('#confirm_admin_password').val();
			var password = $('#admin_password').val();
			if(con_password.length=='')
			{
				$('#conpasscheck').show();
				$('#conpasscheck').html("**This field is required !");
				$('#conpasscheck').focus();
				$('#conpasscheck').css("color","red");
				conpasscheck_err = false;
				return false;
			}else{
				$('#conpasscheck').hide();
			}
			if((con_password.length)<5 || (con_password.length)>8  )
			{
				$('#conpasscheck').show();
				$('#conpasscheck').html("**Password length must be between 5 to 8 !");
				$('#conpasscheck').focus();
				$('#conpasscheck').css("color","red");
				conpasscheck_err = false;
				return false;
			}else{
				$('#conpasscheck').hide();
			}
			if(con_password != password)
			{
				$('#conpasscheck').show();
				$('#conpasscheck').html("**Password Should be same !");
				$('#conpasscheck').focus();
				$('#conpasscheck').css("color","red");
				conpasscheck_err = false;
				return false;
			}else{
				$('#conpasscheck').hide();
			}
		}

		$('#admin_register').click(function(){
			var emailcheck_err = true;
			var passcheck_err = true;
			var conpasscheck_err = true;

			emailcheck_function();
			passwordcheck_function();
			confirmpasswordcheck_function();
			if((emailcheck_err == true) && (passcheck_err==true) &&(conpasscheck_err==true))
			{
				return true;
			}else{
				return false;
			}
		})
	});
</script>
</html>