<?php
include('class/class.php');

$exam = new Register_User;

$exam->user_session_private();

include_once("home_header.php");

if(isset($_POST['user_image_submit'])){

	if(empty($_FILES['file_upload']))
	{
		//echo "<script>alert('Please Upload Photo')</script>";
		$not_upload = 'This field are required !';
	}
	else
	{
        
        $maxsize=2097152;
        $format=array('image/jpeg');
    if($_FILES['file_upload']['size']>=$maxsize){
        $error='File Size too large !';
        //echo '<script>alert("'.$error_1.'")</script>';
    }
    elseif($_FILES['file_upload']['size']==0){
        $error='Invalid File !';
        //echo '<script>alert("'.$error_2.'")</script>';
    }
    elseif(!in_array($_FILES['file_upload']['type'],$format)){
        $error='Format Not Supported.Only .jpeg files are accepted !';
        //echo '<script>alert("'.$error_3.'")</script>';
        }

        else{

          
            $target_dir = "master/user_image/";
            $target_file = $target_dir . basename($_FILES["file_upload"]["name"]);
            if(move_uploaded_file($_FILES["file_upload"]["tmp_name"], $target_file)){
                   $photo =$_FILES["file_upload"]["name"];
                   $query = "UPDATE `user_signup` SET `user_image`='$photo' WHERE `user_id`=".$_SESSION['user_id']."";
                   if($exam->User_Register($query))
                   {
                   	 //echo '<script>alert("uploaded successfully")</script>';
                   	 //echo "<script>window.location='home.php'</script>";
                   	 //echo "The file ". basename($_FILES["file_upload"]["name"]). " has been uploaded.";
                   	$success = 'Photo Upload Success';
                   }
                   else
                   {
                    //	echo '<script>alert("Not Inserted")</script>';

                    $error = 'Not Inserted Image !';
                   }
                   
            }
            else{
                //echo "sorry ";
                $error = 'Not Saved';
                }
            }
        } 
    }

?>
<br />
<br />
<br />
<div class="containter">
		<div class="d-flex justify-content-center">
			<br /><br />
			
			<div class="card" style="margin-top:50px;margin-bottom: 100px;">
        		<div class="card-header"><h4>Upload Photo</h4></div>
        		<div class="card-body">
        			
        			 <?php
        			 if(isset($success))
        			 {
        			 	echo '<div class="alert alert-success">'.$success.'</div>';
        			 }
        			 if(isset($error))
        			 { 
                          echo '<div class="alert alert-danger">'.$error.'</div>';
        			 }
        			 ?>
                   

        				
	        		<form method="post"	id="photo_upload_form" enctype="multipart/form-data">
	        			<div class="form-group">
					        <label>Choose Your Image</label>
					        <input type="file" name="file_upload" id="file_upload" class="form-control" style="width: 250px;" />
					        <p id="pass_err"></p>
					    </div>
					   <!--  <?php
					    $sql = "SELECT user_image WHERE user_id = ".$_SESSION['user_id']." ";
					    if($exam->User_Register($sql))
					    {
					    	foreach ($exam->user_login_details  as $value) {
					    		
					    	

					     ?>
					    <div class="form-group">
					        <img src="master/user_image/<?php echo $value['user_image']; ?>" style="width: 150px; height: 150px; border: 1px solid black; margin: 3px 50px;">
					    </div>
					    <?php

					     }
					    	 
					    }
					    ?> -->

					    <br />
					    <div class="form-group" align="center">
					    	<input type="submit" name="user_image_submit" id="user_image_submit" class="btn btn-info" value="Upload" />
					    </div>
	        		</form>
        		</div>
      		</div>
      		<br /><br />
      		<br /><br />
		</div>
	</div>

</body>
</html>
<script type="text/javascript">
	$(document).ready(function(){
		$('#pass_err').hide();
		var a = $('#file_upload').val();

	 function Check_photo(a)
	 {
		if(a =="")
		{
			$('#pass_err').html("**This is required !");
			$('#pass_err').css("color","red");
			$('#pass_err').focus();
			$('#pass_err').show();
		}
		else
		{
			$('#pass_err').hide();
			return true;
		}
	}

	$('#photo_upload_form').on('submit',function(event){
           
           var a = $('#file_upload').val();
           if( Check_photo(a) == true)
           {
             return true;
           }
           else
           {
           	 Check_photo(a);
           	 return false;
           }
        
		event.preventDefault();
	});

});
</script>