<?php
include_once ("class/class.php");
$user = new Register_User;
$user->user_session_public();
include_once("header.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Now</title>
</head>
<body>
 <div class="container">

      <div class="row">
        <div class="col-md-3">

        </div>
        <div class="col-md-6" style="margin-top:100px;">
          

            <span id="message">
            <?php
            if(isset($_GET['verified']))
            {
              echo '
              <div class="alert alert-success">
                Your email has been verified,you can login now
              </div>
              ';
            }
            ?>   
            </span>
            <div class="card">
              <div class="card-header">User Login</div>
              <div class="card-body">
              	<span id="message1"></span>
                <form method="post" id="user_login_form">
                  <div class="form-group">
                    <label>Enter Email Address :</label>
                      <input type="email" name="user_email_address" id="user_email_address" class="form-control" />
                      <p id="email_err"></p>
                    </div>
                  <div class="form-group">
                    <label>Enter Password :</label>
                    <input type="password" name="user_password" id="user_password" class="form-control" />
                    <p id="password_err"></p>
                  </div>
                  <div class="form-group">
                    <input type="hidden" name="page" value="login" />
                    <input type="hidden" name="action" value="login" />
                    <input type="submit" name="user_login" id="user_login" class="btn btn-info" value="Login" />
                  </div>
                </form>
                <div align="center">
                  <a href="signup.php">Register</a>
                </div>
              </div>
            </div>
        </div>
        <div class="col-md-3">

        </div>
      </div>
  </div>
</body>
<script type="text/javascript">
	$(document).ready(function(){

		 $('#email_err').hide();
		 $('#password_err').hide();

		$('#user_email_address').keyup(function(){
			var a = $('#user_email_address').val();
			Email_check(a);
		});
		function Email_check(a)
		{
            if(a == "")
            {
            	$('#email_err').show();
				$('#email_err').html("**This field is required !");
				$('#email_err').focus();
				$('#email_err').css("color","red");
				return false;

            }
            else
            {
            	$("#email_err").hide();
            	return true;
            }
		}

		$('#user_password').keyup(function(){
			var a = $('#user_password').val();
			password_check(a);
		});

		function password_check(a)
		{
           if(a == "")
            {
            	$('#password_err').show();
				$('#password_err').html("**This field is required !");
				$('#password_err').focus();
				$('#password_err').css("color","red");
				return false;

            }
            else
            {
            	$("password_err").hide();
           
            }
            if(a.length<5 || a.length>8)
            {
            	$('#password_err').show();
				$('#password_err').html("**Password must be between 5 to 8 !");
				$('#password_err').focus();
				$('#password_err').css("color","red");
				return false;

            }
            else
            {
            	$("#password_err").hide();
            	return true;
            }
		}
		

		$('#user_login_form').on('submit', function(event){

                 var email = $('#user_email_address').val();
                 var password = $('#user_password').val();
                 Email_check(email);
                 password_check(password);
                  if((Email_check(email)==true) && (password_check(password)==true))
                  {
                  	$.ajax({
                		url : 'user_ajax_action.php',
                		type :'post',
                		data : $('#user_login_form input').serialize(),
                		dataType:"json",
                		//{

                			// user_email_address : user_email_address,
                			// user_password :user_password,
                			// user_name : user_name,
                			// user_gender : user_gender,
                			// user_email_address : user_email_address,
                			// user_mobile_no :user_mobile_no,
                			// user_register :'Register'
                		//},
                		beforeSend : function(){
                			$('#user_login').val("Please Wait...");
                			$('#user_login').attr('disabled',true);
                		},
                		success : function(data,status){
                                if(data.success)
                                {
                                	location.href='home.php';
                                }
                                else
                                {
                            	$('#message1').html('<div class="alert alert-danger text-danger">'+data.error+'</div>');
                                $('#user_login_form')[0].reset();
                               }
                          
                            $('#user_login').val("Register");
                			$('#user_login').attr('disabled',false);
                		}

                	});
                  }

            	event.preventDefault();
            });
	});
</script>
</html>