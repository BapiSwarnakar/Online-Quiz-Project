<?php

class Register_User
{
var $host;
var $username;
var $password;
var $database;
var $connect;
var $home_page;
var $query ;
var $lastid;
var $user_login_details;
var $fetch_value;
var $Data_fetch;
var $result_display;
var $navigation_id;


function __construct()
	{
		$this->host = 'localhost';
		$this->username = 'root';
		$this->password = '';
		$this->database = 'online_quiz_project';
		$this->home_page = 'http://localhost/online_quiz_project/';
		$this->connect= new mysqli($this->host,$this->username,$this->password,$this->database);
		// if(!$this->connect)
		// {
  //         echo "Error".mysql_error();
		// }
		// else
		// {
		// 	echo "Service Available";
      session_start();
		//}


    }

    public function User_Register($data){

    	if($this->connect->query($data))
    	{

         $this->lastid = $this->connect->insert_id;
         return true;
    	}
    	else{
    	 
          return false;
    	}

    }


    public function Check_Email($data){

       $query= $this->connect->query($data);
    	 $fetch = $query->fetch_array(MYSQLI_ASSOC);
	    if($query->num_rows>0)
	     {
	     	//$_SESSION['ss']="$email";
	     	return True;
	    }
	    else
	     {
	     	return False;
	     }

    }
  function Send_email($receiver_email,$subject,$body)
    {
      $mail = new PHPMailer;

    $mail->IsSMTP();

    $mail->Host = 'smtp.gmail.com';

    $mail->Port = '587';

    $mail->SMTPAuth = true;

    $mail->Username = 'swarnakarr34@gmail.com';

    $mail->Password = 'Bapi@!123';

    $mail->SMTPSecure = 'tls';

    $mail->From = 'info@Codewithbapi.info';

    $mail->FromName = 'info@Codewithbapi.info';

    $mail->AddAddress($receiver_email, '');

    $mail->IsHTML(true);

    $mail->Subject = $subject;

    $mail->Body = $body;

    //$mail->AddEmbeddedImage('first.png','apple');

    if($mail->Send())
    {
      return true;
    }
    else
    {
      return "{$mail->ErrorInfo}";
    }
    
  }
  
        

 public function user_login($query)
 {
       $query= $this->connect->query($query);
        if($query->num_rows>0)
        { 
            while($result = $query->fetch_array(MYSQLI_ASSOC))
             {
                $this->user_login_details[] = $result;
             }
            
            return $this->user_login_details;
            return true;
        
        }
        else{
            return false;
        }   

    }

function Number_of_Row($query)
  {
    $query = $this->connect->query($query);
    $row = $query->num_rows;
    if($row)
     { 
        return $row;
      }
  }

 public function Fetch_Data($query)
 {
       $query= $this->connect->query($query);
        if($query->num_rows>0)
        { 
            while($result = $query->fetch_array(MYSQLI_ASSOC))
             {
                $this->fetch_value[] = $result;
             }
            
            return $this->fetch_value;
            return true;
        
        }
        else{
            return false;
        }   

    }


  public function Data_display($query)
     {
       $query= $this->connect->query($query);
        if($query->num_rows>0)
        { 
            while($result[] = $query->fetch_array(MYSQLI_ASSOC))
             {
                 
                 
             }
             return $result;

            //return $this->Data_fetch;
          
            return true;
        
        }
        else{
            return false;
        }   

    }

   public function result_display($query)
     {
       $query= $this->connect->query($query);
        if($query->num_rows>0)
        { 
            while($result = $query->fetch_array(MYSQLI_ASSOC))
             {
                $this->result_display[] = $result;
             }
            
            return $this->result_display;
            return true;
        
        }
        else{
            return false;
        }   

    }


      public function redirect($page)
        {
          header('location:'.$page.'');
          exit;
        }

      public function user_session_public()
        {
        if(isset($_SESSION['user_id']))
        {
          $this->redirect('home.php');
        }
     }

     public function user_session_private()
        {
        if(!isset($_SESSION['user_id']))
        {
          $this->redirect('login.php');
        }
     }

  public function admin_session_private()
      {
      if(!isset($_SESSION['admin_id']))
      {
        $this->redirect('index.php');
      }
    }

  public function admin_session_public()
    {
      if(isset($_SESSION['admin_id']))
      {
        $this->redirect('admin_dashboard.php');
      }
    }

  function clean_data($data)
   {
    $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
  }


  function Get_exam_question_limit($exam_id)
  {
    $sql = "SELECT `total_question` FROM `online_exam_table` WHERE  `online_exam_id`='$exam_id'";
    $query= $this->connect->query($sql);
    $result = $query->fetch_array(MYSQLI_ASSOC);
    if($result)
    {   
       return $result['total_question'];
    }
  }

  function Get_exam_total_question($exam_id)
  {
    $sql = "SELECT `question_id` FROM `question_table` WHERE  `online_exam_id` = '$exam_id'";
    $query = $this->connect->query($sql);
    $row = $query->num_rows;
    if($row)
     { 
        return $row;
      }
  }

  function Is_allowed_add_question($exam_id)
  {
    $exam_question_limit = $this->Get_exam_question_limit($exam_id);

    $exam_total_question = $this->Get_exam_total_question($exam_id);

    if($exam_total_question >= $exam_question_limit)
    {
      return false;
    }
    return true;
  }


function Is_exam_is_not_started($online_exam_id)
  {
    date_default_timezone_set('Asia/Kolkata');
    $current_datetime = date("Y-m-d") . ' ' . date("H:i:s", STRTOTIME(date('h:i:sa')));

    $exam_datetime = '';
     $sql = " SELECT  `online_exam_datetime` FROM `online_exam_table` WHERE `online_exam_id` = '$online_exam_id'";
     $query = $this->connect->query($sql);
     $result = $query->fetch_array(MYSQLI_ASSOC);

    if($result)
    {
      $exam_datetime = $result['online_exam_datetime'];
    }

    if($exam_datetime > $current_datetime)
    {
      return true;
    }
    return false;
  }

  function Get_Exam_Id($exam_code)
  {
    $sql = "SELECT `online_exam_id` FROM `online_exam_table` WHERE  `online_exam_code`='$exam_code'";
    $query = $this->connect->query($sql);
    $result = $query->fetch_array(MYSQLI_ASSOC);
    if($result)
     {
        return $result['online_exam_id'];
    }
  }
  

  function Fill_exam_list()
  {
    $query= "
      SELECT online_exam_id, online_exam_title 
      FROM online_exam_table 
      WHERE online_exam_status = 'Created' OR online_exam_status = 'Pending' 
      ORDER BY online_exam_title ASC
    ";
    $result = $this->connect->query($query);
    if($result->num_rows>0)
        { 
            while($fetch = $result->fetch_array(MYSQLI_ASSOC))
             {
                 $output .= '<option value="'.$fetch['online_exam_id'].'">'.$fetch['online_exam_title'].'</option>';
             } 
            return $output;        
        }
    
  }

  function If_user_already_enroll_exam($exam_id, $user_id)
  {
    $query = "
    SELECT * FROM user_exam_enroll_table 
    WHERE exam_id = '$exam_id' 
    AND user_id = '$user_id'
    ";
    $result = $this->connect->query($query);
    if($result->num_rows >0)
    {
      return true;
    }
    return false;
  }


  function Change_exam_status($user_id)
  {
   

    $query = "
    SELECT * FROM user_exam_enroll_table 
    INNER JOIN online_exam_table 
    ON online_exam_table.online_exam_id = user_exam_enroll_table.exam_id 
    WHERE user_exam_enroll_table.user_id = '".$user_id."'
    ";

    $result = $this->connect->query($query);
    if($result)
    {
      date_default_timezone_set('Asia/Kolkata');
      $current_datetime = date("Y-m-d") . ' ' . date("H:i:s", STRTOTIME(date('h:i:sa')));
    
      //$currentTime = date( 'h:i:s A', time () );


      while($fetch = $result->fetch_array(MYSQLI_ASSOC))
        {
              $exam_start_time = $fetch["online_exam_datetime"];
              $duration = $fetch["online_exam_duration"] . ' minute';
              $exam_end_time = strtotime($exam_start_time . '+' . $duration);
              $exam_end_time = date('Y-m-d H:i:s', $exam_end_time);

              if($current_datetime >= $exam_start_time && $current_datetime <= $exam_end_time)
                {
                  //exam started
                  $data = array(
                    ':online_exam_status' =>  'Started'
                  );
                  $online_exam_status = $data[':online_exam_status'];

                  $sql = "
                  UPDATE online_exam_table 
                  SET online_exam_status = '$online_exam_status' 
                  WHERE online_exam_id = '".$fetch['online_exam_id']."'
                  ";

                  $this->connect->query($sql);
                }
                else
                  {
                    if($current_datetime > $exam_end_time)
                    {
                      //exam completed
                      $data = array(
                        ':online_exam_status' =>  'Completed'
                      );

                      $online_exam_status = $data[':online_exam_status'];

                      $query = "
                      UPDATE online_exam_table 
                      SET online_exam_status ='$online_exam_status' 
                      WHERE online_exam_id = '".$fetch['online_exam_id']."'
                      ";

                      $this->connect->query($query);
                    }         
                  }
          //      echo "current time : ".$current_datetime."<br>";
          // echo "start time : ".$exam_start_time."<br>";
          // echo "duration : ".$duration."<br>";
          // echo "end time : ".$exam_end_time."<br><br>";
          } 
         

      }
   }

  function Get_question_right_answer_mark($exam_id)
  {
    $sql = "
    SELECT marks_per_right_question FROM online_exam_table 
    WHERE online_exam_id = '".$exam_id."' 
    ";

    $result = $this->connect->query($sql);

    foreach($result as $row)
    {
      return $row['marks_per_right_question'];
    }
  }

  function Get_question_wrong_answer_mark($exam_id)
  {
    $sql = "
    SELECT marks_per_wrong_question FROM online_exam_table 
    WHERE online_exam_id = '".$exam_id."' 
    ";

    $result = $this->connect->query($sql);

    foreach($result as $row)
    {
      return $row['marks_per_wrong_question'];
    }
  }
function Get_question_answer_option($question_id)
  {
    $sql = "
    SELECT answer_option FROM question_table 
    WHERE question_id = '".$question_id."' 
    ";

    $result = $this->connect->query($sql);

    foreach($result as $row)
    {
      return $row['answer_option'];
    }
  }

  function Get_exam_status($exam_id)
  {
    $query = "
    SELECT online_exam_status FROM online_exam_table 
    WHERE online_exam_id = '".$exam_id."' 
    ";
    $result = $this->connect->query($query);
    foreach($result as $row)
    {
      return $row["online_exam_status"];
    }
  }
   
  function Get_user_exam_status($exam_id, $user_id)
  {
    $query = "
    SELECT attendence_status 
    FROM user_exam_enroll_table 
    WHERE exam_id = '$exam_id' 
    AND user_id = '$user_id'
    ";
    $result = $this->connect->query($query);
    foreach($result as $row)
    {
      return $row["attendence_status"];
    }
  }

  function Check_Navigation_Button($user_id,$exam_id)
  {

     $query = "SELECT user_answer_option,question_id FROM user_exam_question_answer WHERE user_id ='$user_id' AND exam_id='$exam_id'  ORDER BY question_id ASC ";
     $result = $this->connect->query($query);
      if($result->num_rows>0)
        { 
            while($fetch = $result->fetch_array(MYSQLI_ASSOC))
             {
                $this->navigation_id[] = $fetch;
             }
            
            return $this->navigation_id;
        }

     

  }

   







}

 
?>