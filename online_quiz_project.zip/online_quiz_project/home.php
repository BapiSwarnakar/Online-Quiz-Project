<?php
include_once("class/class.php");
$user = new Register_User;

include_once("home_header.php");
 if(isset($_SESSION['user_id']))
  {
  ?>
   <br />
   <br />
   <br />
   <br />
   <br />
   <br />
   <br />
   <br />
     <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <select name="exam_list" id="exam_list" class="form-control input-lg">
          <option value="">Select Exam</option>
          <?php

          echo $user->Fill_exam_list();

          ?>
        </select>
        <br />
        <span id="exam_details"></span>
      </div>
      <div class="col-md-3"></div>
    </div>
    <script type="text/javascript">
      $(document).ready(function(){

      $('#exam_list').parsley();

      var exam_id = '';

      $('#exam_list').change(function(){

        $('#exam_list').attr('required', 'required');

        if($('#exam_list').parsley().validate())
        {
          exam_id = $('#exam_list').val();
          $.ajax({
            url:"user_ajax_action.php",
            method:"POST",
            data:{action:'fetch_exam', page:'home', exam_id:exam_id},
            success:function(data)
            {
               $('#exam_details').html(data);
              //alert(data);
            }
          });
        }
      });

      $(document).on('click', '#enroll_button', function(){
        var exam_id = $('#enroll_button').data('exam_id');
        $.ajax({
          url:"user_ajax_action.php",
          method:"POST",
          data:{action:'enroll_exam', page:'home', exam_id:exam_id},
          beforeSend:function()
          {
            $('#enroll_button').attr('disabled', 'disabled');
            $('#enroll_button').text('please wait');
          },
          success:function()
          {
            $('#enroll_button').attr('disabled','disabled');
            $('#enroll_button').removeClass('btn-warning');
            $('#enroll_button').addClass('btn-success');
            $('#enroll_button').text('Thankyou,You are Accepted');
          }
        });
      });


    });
    </script>

  <?php
  }
else
{
	?>  

  <div class="container-fluid">
	<div align="center" style="margin-top: 5%;">
			<p><a href="signup.php" class="btn btn-primary btn-lg">Register</a></p>
			<p><a href="login.php" class="btn btn-danger btn-lg">Login</a></p>
		</div>
		</div>
		</body>
</html>
<?php
}

?>