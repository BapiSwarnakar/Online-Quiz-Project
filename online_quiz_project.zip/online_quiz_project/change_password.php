<?php
include('class/class.php');

$exam = new Register_User;

$exam->user_session_private();

include_once("home_header.php");


?>
<br />
<br />
<br />
<br />
<div class="containter">
		<div class="d-flex justify-content-center">
			<br /><br />
			
			<div class="card" style="margin-top:50px;margin-bottom: 100px;">
        		<div class="card-header"><h4>Change Password</h4></div>
        		<div class="card-body">
        			<span id="message"></span>
	        		<form method="post"	id="change_password_form">
	        			<div class="form-group">
					        <label>Enter Password</label>
					        <input type="password" name="user_password" id="user_password" class="form-control" />
					        <p id="pass_err"></p>
					    </div>
					    <div class="form-group">
					        <label>Enter Confirm Password</label>
					        <input type="password" name="confirm_user_password" id="confirm_user_password" class="form-control" />
					        <p id="con_err"></p>
					    </div>
					    <br />
					    <div class="form-group" align="center">
					    	<input type="hidden" name="page" value="change_password" />
					    	<input type="hidden" name="action" value="change_password" />
					    	<input type="submit" name="user_password" id="user_password_submit" class="btn btn-info" value="Change" />
					    </div>
	        		</form>
        		</div>
      		</div>
      		<br /><br />
      		<br /><br />
		</div>
	</div>

</body>

</html>
<script type="text/javascript">
	$(document).ready(function(){
		$('#pass_err').hide();
		$('#con_err').hide();

		$('#user_password').keyup(function(){
			var a = $('#user_password').val();
			password_check(a);
		});
		 function password_check(a)
		 {
		 	if(a=="")
		 	{
		 		$('#pass_err').html("**This field is required !");
		 		$('#pass_err').css("color","red");
		 		$('#pass_err').focus();
		 		$('#pass_err').show();
		 		return false;
		 	}
		 	else
		 	{
		 		$('#pass_err').hide();
		 	}
		    if(a.length <5 || a.length>8)
		 	{
		 		$('#pass_err').html("**Password must between 5 to 8 !");
		 		$('#pass_err').css("color","red");
		 		$('#pass_err').focus();
		 		$('#pass_err').show();
		 		return false;
		 	}
		 	else
		 	{
		 		$('#pass_err').hide();
		 		return true;
		 	}
		 }


		$('#confirm_user_password').keyup(function(){
			var a = $('#confirm_user_password').val();
			Confirm_password_check(a);
		});
		 function Confirm_password_check(a)
		 {
		 	if(a=="")
		 	{
		 		$('#con_err').html("**This field is required !");
		 		$('#con_err').css("color","red");
		 		$('#con_err').focus();
		 		$('#con_err').show();
		 		return false;
		 	}
		 	else
		 	{
		 		$('#con_err').hide();
		 	}
		    if(a.length <5 || a.length>8)
		 	{
		 		$('#con_err').html("**Password must between 5 to 8 !");
		 		$('#con_err').css("color","red");
		 		$('#con_err').focus();
		 		$('#con_err').show();
		 		return false;
		 	}
		 	else
		 	{
		 		$('#con_err').hide();

		 	}
		 	if(a != $('#user_password').val())
		 	{
                $('#con_err').html("**Password Should be Match !");
		 		$('#con_err').css("color","red");
		 		$('#con_err').focus();
		 		$('#con_err').show();
		 		return false;
		 	}
		 	else
		 	{
		 		$('#con_err').hide();
		 		return true;
		 	}
		 }


		 $('#change_password_form').on('submit',function(event){

		 	var password = $('#user_password').val();
            var con_password = $('#confirm_user_password').val();
           
            password_check(password);
            Confirm_password_check(con_password);

            if( (password_check(password) == true ) &&  (Confirm_password_check(con_password) == true) )
            {
            	
            	$.ajax({
                		url : "user_ajax_action.php",
                		type :"post",
                		data : $('#change_password_form input').serialize(),
                	    dataType:"json",
                	    
                		//{

                			// user_email_address : user_email_address,
                			// user_password :user_password,
                			// user_name : user_name,
                			// user_gender : user_gender,
                			// user_email_address : user_email_address,
                			// user_mobile_no :user_mobile_no,
                			// user_register :'Register'
                		//},
                		beforeSend : function(){
                			$('#user_password_submit').val("Please Wait...");
                			$('#user_password_submit').attr('disabled',true);
                			
                		},
                		success : function(data,status){
							    if(data.success)
                                {
                                	//alert("Your Registration Successfully Done . "+data.success);
	                            	$('#message').html('<div class="alert alert-success">'+data.success+'</div>');
	                                $('#change_password_form')[0].reset();
                                }
	                            else
	                            {
	                             	$('#message').html('<div class="alert alert-danger text-danger">'+data.error+'</div>');
	                             	$('#user_email_address').css("border","1px solid red");
	                            }
                         $('#user_password_submit').val("Register");
                		$('#user_password_submit').attr('disabled',false);

                		}

                	});

            }

		 	event.preventDefault();
		 });



	});
</script>