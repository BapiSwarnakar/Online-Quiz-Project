
<?php
 include_once("header.php");
  ?>

<main role="main">

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role=""><rect width="100%" height="100%" fill="#777"/><img src="first.png" width="100%" height="100%"></svg>
      </div>
      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img"><rect width="100%" height="100%" fill="#777"/><img src="second.png" width="100%" height="100%"></svg>
      </div>
      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img"><rect width="100%" height="100%" fill="#777"/><img src="third.jpg" width="100%" height="100%"></svg>
      </div>
    </div>
    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->

  <div class="container marketing">

    <!-- Three columns of text below the carousel -->


    <!-- START THE FEATURETTES -->

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="featurette-heading">First featurette heading. <span class="text-muted">General knowledge.</span></h2>
        <p class="lead">General knowledge is information that has been accumulated over time through various mediums.[1] It excludes specialized learning that can only be obtained with extensive training and information confined to a single medium. General knowledge is an essential component of crystallized intelligence. It is strongly associated with general intelligence and with openness to experience.</p>
        <p class="lead">People high in general knowledge[14] tend to be highly open to new experiences[8][9][10][12] and in typical intellectual engagement.[9][10] The relationship between openness to experience and general knowledge remains robust even when IQ is taken into account.[8][10] People high in openness may be more motivated to engage in intellectual pursuits that increase their knowledge.[10] Relationships between general knowledge and other five factor model traits tend to be weak and inconsistent. Though one study found that extraversion and neuroticism were negatively correlated with general knowledge,[9] others found that they were unrelated.[8][12] Inconsistent results have also been found for conscientiousness.</p>
      </div>
      <div class="col-md-5">

        <img src="s1.jpg" width="250" height="300">

      </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7 order-md-2">
        <h2 class="featurette-heading">Oh yeah, it’s that good. <span class="text-muted">Online Quiz.</span></h2>
        <p class="lead">The earliest known examples of the word date back to 1780; its etymology is unknown, but it may have originated in student slang. It initially meant an "odd, eccentric person"[a] or a "joke, hoax". Later (perhaps by association with words such as "inquisitive") it came to mean "to observe, study intently", and thence (from about mid-19th century) "test, exam."[2][3]</p>

<p class="lead">There is a well-known myth about the word quiz that says that in 1791 a Dublin theater owner named Richard Daly made a bet that he could introduce a word into the language within 24 hours. He then went out and hired a group of street urchins to write the word "quiz", which was a nonsense word, on walls around the city of Dublin. Within a day, the word was common currency and had acquired a meaning (since no one knew what it meant, everyone thought it was some sort of test) and Daly had some extra cash in his pocket.[4] However, there is no evidence to support the story, and the term was already in use before the alleged bet in 1791.</p>
      </div>
      <div class="col-md-5 order-md-1">

         <img src="s2.jpg" width="250" height="300">
      </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="featurette-heading">And lastly, this one. <span class="text-muted">Time Maintain.</span></h2>
        <p class="lead">Time is a measure in which events can be ordered from the past through the present into the future, and also the measure of durations of events and the intervals between them. ... My best shot at a definition of time is this: Time is the dimension on which the evolution of state of a system is allowed to occur.</p>
      </div>
      <div class="col-md-5">
        <img src="s3.jfif" width="250" height="300">
      </div>
    </div>

    <hr class="featurette-divider">

    <!-- /END THE FEATURETTES -->

  </div><!-- /.container -->
  <?php include_once("footer.php"); ?>
