<?php
include_once ('class/class.php');
$user = new Register_User;

$user->user_session_public();

include_once('header.php');
?>
<body>
<div class="containter" style="margin-top: 5%;">
		<div class="d-flex justify-content-center">
			<br /><br />
			<div class="card col-lg-4" style="margin-top:50px;margin-bottom: 100px;">
        		<div class="card-header"><h4>User Registration</h4></div>
        		<div class="card-body">
        			   <span id="message"></span>
                <form method="post" id="user_register_form">
                  <div class="form-group">
                    <label>Enter Email Address</label>
                    <input type="email" name="user_email_address" id="user_email_address" class="form-control" data-parsley-checkemail data-parsley-checkemail-message='Email Address already Exists' />
                    <p id="email_err"></p>
                  </div>
                  <div class="form-group">
                    <label>Enter Password</label>
                    <input type="password" name="user_password" id="user_password" class="form-control" />
                    <p id="password_err"></p>
                  </div>
                  <div class="form-group">
                    <label>Enter Confirm Password</label>
                    <input type="password" name="confirm_user_password" id="confirm_user_password" class="form-control" />
                    <p id="con_password_err"></p>
                  </div>
                  <div class="form-group">
                    <label>Enter Name</label>
                    <input type="text" name="user_name" id="user_name" class="form-control" /> 
                    <p id="name_err"></p>
                  </div>
                  <div class="form-group">
                    <label>Select Gender</label>
                    <select name="user_gender" id="user_gender" class="form-control">
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                  </select> 
                  </div>
                  <div class="form-group">
                    <label>Enter Address</label>
                    <textarea name="user_address" id="user_address" class="form-control"></textarea>
                    <p id="address_err"></p>
                  </div>
                  <div class="form-group">
                    <label>Enter Mobile Number</label>
                    <input type="text" name="user_mobile_no" id="user_mobile_no" class="form-control" /> 
                    <p id="mobile_err"></p>
                  </div>
                  <br />
                  <div class="form-group" align="center">
                    <input type="hidden" name='page' value='register' />
                    <input type="hidden" name="action" value="register" />
                    <input type="submit" name="user_register" id="user_register" class="btn btn-info" value="Register" />
                  </div>
                </form>
          			<div align="center">
          				<a href="login.php">Login</a>
          			</div>
        		</div>
      		</div>
      		<br /><br />
      		<br /><br />
		</div>
	</div>
 <script type="text/javascript">
 	 $(document).ready(function(){
			   $('#email_err').hide();
			   $('#password_err').hide();
			   $('#con_password_err').hide();
			   $('#name_err').hide();
			   $('#address_err').hide();
			   $('#mobile_err').hide();
			   $('#image_err').hide();

// /////////////////////// EMAIL ADDRESS CHECK ///////////////////////////////////////
	  $('#user_email_address').keyup(function(){
	  	 var a= $('#user_email_address').val();
			email_address(a);
		});

			function email_address(a)
			{
				if(a=="")
				 {
				$('#email_err').show();
				$('#email_err').html("**This field is required !");
				$('#email_err').focus();
				$('#email_err').css("color","red");
				return false;
				}
				else
				{
					$('#email_err').hide();
					return true;
				}
			}
// ////////////////////// PASSWORD CHECK //////////////////////////////////////////////////
	$('#user_password').keyup(function(){
	  	 var b= $('#user_password').val();
			user_password(b);
		});

			function user_password(a)
			{
				if(a=="")
				 {
				$('#password_err').show();
				$('#password_err').html("**This field is required !");
				$('#password_err').focus();
				$('#password_err').css("color","red");
				return false;
				}
				else
				{
					$('#password_err').hide();
				}
				if(a.length <5 || a.length>8)
				 {
				$('#password_err').show();
				$('#password_err').html("**Input between 5 to 8 values !");
				$('#password_err').focus();
				$('#password_err').css("color","red");
				return false;
				}
				else
				{
					$('#password_err').hide();
					return true;
				}
			}
	// ////////////////CONFIRM PASSWORD CHECK ///////////////////////////////////////

	$('#confirm_user_password').keyup(function(){
	  	 var b= $('#confirm_user_password').val();
			confirm_password(b);
		});

			function confirm_password(a)
			{
				var con = $('#user_password').val();
				if(a=="")
				 {
				$('#con_password_err').show();
				$('#con_password_err').html("**This field is required !");
				$('#con_password_err').focus();
				$('#con_password_err').css("color","red");
				return false;
				}
				else
				{
					$('#con_password_err').hide();
					
				}
				if(a.length <5 || a.length>8)
				 {
				$('#con_password_err').show();
				$('#con_password_err').html("**Input between 5 to 8 values !");
				$('#con_password_err').focus();
				$('#con_password_err').css("color","red");
				return false;
				}
				else
				{
					$('#con_password_err').hide();
					
				}
				if(a != con)
				 {
				$('#con_password_err').show();
				$('#con_password_err').html("**Should be the match !");
				$('#con_password_err').focus();
				$('#con_password_err').css("color","red");
				return false;
				}
				else
				{
					$('#con_password_err').hide();
					return true;
				}
			   
			}
// /////////////////// NAME CHECK //////////////////////////////////////


        $('#user_name').keyup(function(){
	  	 var b = $('#user_name').val();
			valid_name(b);
		});

			function valid_name(a)
			{
				if(a=="")
				 {
				$('#name_err').show();
				$('#name_err').html("**This field is required !");
				$('#name_err').focus();
				$('#name_err').css("color","red");
				return false;
				}
				else
				{
					$('#name_err').hide();
				}
				if(!isNaN(a))
				 {
				$('#name_err').show();
				$('#name_err').html("**Not valid!");
				$('#name_err').focus();
				$('#name_err').css("color","red");
				return false;
				}
				else
				{
					$('#name_err').hide();
					return true;
				}
			}
// //////////////// ADDRESS CHECK //////////////////////////////////////

       $('#user_address').keyup(function(){
	  	 var b = $('#user_address').val();
			valid_address(b);
		});

			function valid_address(a)
			{
				if(a=="")
				 {
				$('#address_err').show();
				$('#address_err').html("**This field is required !");
				$('#address_err').focus();
				$('#address_err').css("color","red");
				return false;
				}
				else
				{
					$('#address_err').hide();
					return true;
				}
			}
// /////////////////MOBILE NO CHECK //////////////////////////

       $('#user_mobile_no').keyup(function(){
	  	 var b = $('#user_mobile_no').val();
			valid_mobile(b);
		});

			function valid_mobile(a)
			{
				if(a=="")
				 {
				$('#mobile_err').show();
				$('#mobile_err').html("**This field is required !");
				$('#mobile_err').focus();
				$('#mobile_err').css("color","red");
				return false;
				}
				else
				{
					$('#mobile_err').hide();
				
				}
				if(isNaN(a))
				 {
				$('#mobile_err').show();
				$('#mobile_err').html("**Not valid!");
				$('#mobile_err').focus();
				$('#mobile_err').css("color","red");
				return false;
				}
				else
				{
					$('#mobile_err').hide();
					return true;
				}
				if(a.length < 10)
				 {
				$('#mobile_err').show();
				$('#mobile_err').html("**field valid mobile no !");
				$('#mobile_err').focus();
				$('#mobile_err').css("color","red");
				return false;
				}
				else
				{
					$('#mobile_err').hide();
				}
				
			}


			$('#user_register_form').on('submit', function(event){
                var email = $('#user_email_address').val();
                 var password = $('#user_password').val();
                 var con_password = $('#confirm_user_password').val();
                 var name = $('#user_name').val();
                 var address = $('#user_address').val();
                 var mobile = $('#user_mobile_no').val();

				email_address(email);
				user_password(password);
				confirm_password(con_password);
				valid_name(name);
                valid_address(address);
                valid_mobile(mobile);

                if((email_address(email)==true) && (user_password(password)==true) && (confirm_password(con_password)==true) &&(valid_name(name)==true) &&(valid_address(address)==true) && (valid_mobile(mobile)==true))
                {
                	
                	$.ajax({
                		url : "user_ajax_action.php",
                		type :"post",
                		data : $('#user_register_form input,select,textarea').serialize(),
                	    dataType:"json",
                	    
                		//{

                			// user_email_address : user_email_address,
                			// user_password :user_password,
                			// user_name : user_name,
                			// user_gender : user_gender,
                			// user_email_address : user_email_address,
                			// user_mobile_no :user_mobile_no,
                			// user_register :'Register'
                		//},
                		beforeSend : function(){
                			$('#user_register').val("Please Wait...");
                			$('#user_register').attr('disabled',true);
                			
                		},
                		success : function(data,status){
							    if(data.success)
                                {
                                	alert("Your Registration Successfully Done . "+data.success);
	                            	$('#message').html('<div class="alert alert-success">'+data.success+'</div>');
	                                $('#user_register_form')[0].reset();
                                }
	                            else
	                            {
	                             	$('#message').html('<div class="alert alert-danger text-danger">'+data.error+'</div>');
	                             	$('#user_email_address').css("border","1px solid red");
	                            }
                         $('#user_register').val("Register");
                		$('#user_register').attr('disabled',false);
                		}

                	});
                }
				event.preventDefault();
				
              });

		});
 </script>
</body>
</html>