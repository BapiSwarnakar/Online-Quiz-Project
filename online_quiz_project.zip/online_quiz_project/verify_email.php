<?php 
 include_once ('class/class.php');
 $user = new Register_User;


if(isset($_GET['type'], $_GET['code']))
{

if($_GET['type'] == 'master')
	{
		$query= "
		UPDATE admin_table 
		SET email_verified = 'yes'
		WHERE admin_verification_code = '".$_GET['code']."'
		";
     if($user->User_Register($query))
        {
        	echo "<script>window.location='master/index.php?verified=success'</script>";
        }
    }


  if($_GET['type'] == 'user')
	{

		$query = "UPDATE user_signup SET `user_email_verified`='yes' 
		WHERE user_verification_code ='".$_GET['code']."'";
        if($user->User_Register($query))
        {
        	echo "<script>window.location='login.php?verified=success'</script>";
        }
	}
}

?>
