<?php
include('class/class.php');

$user = new Register_User;

$user->user_session_private();

$user->Change_exam_status($_SESSION['user_id']);

include('home_header.php');
?>
<br />
<br />
<br />
<br />
<div class="card">
	<div class="card-header">Online Exam List</div>
	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover" id="exam_data_table">
				<thead>
					<tr>
						<th>Exam Title</th>
						<th>Date & Time</th>
						<th>Duration</th>
						<th>Total Question</th>
						<th>Right Answer Mark</th>
						<th>Wrong Answer Mark</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="enroll_details">
					
				</tbody>
			</table>
		</div>
	</div>
</div>
</div>
</body>
</html>
<script type="text/javascript">
$(document).ready(function(){
	Display();
	function Display()
	  {
		$.ajax({
			url : 'user_ajax_action.php',
			type : 'post',
			data : {action :'enroll_fetch',page:'enroll'},
			success : function(data){
				//alert(data);
				$('#enroll_details').html(data);
				}
		    });
	   }
	});
</script>