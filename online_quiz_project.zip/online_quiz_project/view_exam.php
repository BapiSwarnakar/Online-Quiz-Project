
<?php
include('class/class.php');

$exam = new Register_User;

$exam->user_session_private();
$exam->Change_exam_status($_SESSION['user_id']);
include('home_header.php');

$exam_id = '';
$exam_status = '';
$remaining_minutes = '';

if(isset($_GET['code']))
{
	$exam_id = $exam->Get_exam_id($_GET["code"]);
	$query = "
	SELECT online_exam_status, online_exam_datetime, online_exam_duration FROM online_exam_table 
	WHERE online_exam_id = '$exam_id'
	";
   if($exam->Fetch_Data($query))
   {
  
    date_default_timezone_set('Asia/Kolkata');
   	foreach($exam->fetch_value as $row)
	{

		$exam_status = $row['online_exam_status'];
		$exam_star_time = $row['online_exam_datetime'];
		$duration = $row['online_exam_duration'] . ' minute';
		$exam_end_time = strtotime($exam_star_time . '+' . $duration);
        
		$exam_end_time = date('Y-m-d H:i:s', $exam_end_time);
		$remaining_minutes = strtotime($exam_end_time) - time();

		// echo $exam_status."<br>";
		// echo $exam_star_time."<br>";
		// echo $duration."<br>";
		// echo $exam_end_time."<br>";
		// echo $remaining_minutes;
	}

   }
	
}
else
{
	header('location:enroll_exam.php');
}


?>


<br />
<?php
if($exam_status == 'Started')
{
	$data = array(
		':user_id'		=>	$_SESSION['user_id'],
		':exam_id'		=>	$exam_id,
		':attendence_status'	=>	'Present'
	);

	$user_id = $data[':user_id'];
	$exam_id = $data[':exam_id'];
	$attendence_status = $data[':attendence_status'];

	$query = "
	UPDATE user_exam_enroll_table 
	SET attendence_status = '$attendence_status' 
	WHERE user_id = '$user_id'
	AND exam_id = '$exam_id'
	";

	$exam->User_Register($query);

?>
<br />
<br />
<br />
<div class="row">
	<div class="col-md-4">
		<br />
		<div id="user_details_area"></div>	
		<div align="center">
			<div id="exam_timer" data-timer="<?php echo $remaining_minutes; ?>" style="max-width:400px; width: 100%; height: 200px;"></div>
		</div>
	</div>

	<div class="col-md-4">
		<br />
		<br />
		<div class="card">
			<div class="card-header">Online Exam</div>
			<div class="card-body">
				<div id="single_question_area" style="margin-left: 0px;"></div>
			</div>
		</div>
		<br />
	</div>
	<div class="col-md-4">
		<br />
		<div id="question_navigation_area"></div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
	var exam_id = "<?php echo $exam_id; ?>";

	load_question();
	question_navigation();

	function load_question(question_id='')
	{
		$.ajax({
			url:"user_ajax_action.php",
			method:"POST",
			data:{exam_id:exam_id, question_id:question_id, page:'view_exam', action:'load_question'},
			success:function(data)
			{
				$('#single_question_area').html(data);
				//location.reload(true);
			}
		});
	}

	$(document).on('click', '.next', function(){
		var question_id = $(this).attr('id');
		load_question(question_id);
	});

	$(document).on('click', '.previous', function(){
		var question_id = $(this).attr('id');
		load_question(question_id);
		//location.reload();
	});

	function question_navigation()
	{
		$.ajax({
			url:"user_ajax_action.php",
			method:"POST",
			data:{exam_id:exam_id, page:'view_exam', action:'question_navigation'},
			success:function(data)
			{
				$('#question_navigation_area').html(data);
				//location.reload();
			}
		});
	}

	$(document).on('click', '.question_navigation', function(){
		var question_id = $(this).data('question_id');
		load_question(question_id);
	});

	function load_user_details()
	{
		$.ajax({
			url:"user_ajax_action.php",
			method:"POST",
			data:{page:'view_exam', action:'user_detail'},
			success:function(data)
			{
				$('#user_details_area').html(data);
			}
		})
	}

	load_user_details();


	$("#exam_timer").TimeCircles({ 
		time:{
			Days:{
				show: false
			},
			Hours:{
				show: false
			}
		}
	});
	setInterval(function(){
		var remaining_second = $("#exam_timer").TimeCircles().getTime();
		if(remaining_second < 1)
		{
			//alert('Exam time over');
			location.reload(true);
		}
	}, 1000);


	////////   ANSWER CHECK  //////////////


	 $(document).on('click', '.answer_option', function(){
		var question_id = $(this).data('question_id');

		var answer_option = $(this).data('id');

		$.ajax({
			url:"user_ajax_action.php",
			method:"POST",
			data:{question_id:question_id, answer_option:answer_option, exam_id:exam_id, page:'view_exam', action:'answer'},
			success:function(data)
			{
                 //alert(data);
                 //location.reload();
			}
		})
	});


});
</script>
<?php
}
if($exam_status == 'Completed')
{
	
	//echo $exam->query;
?>
  <br />
  <br />
  <br />
	<div class="card">
		<div class="card-header">
			<div class="row">
				<div class="col-md-8">Online Exam Result</div>
				<div class="col-md-4" align="right">
					<a href="pdf_exam_result.php?code=<?php echo $_GET["code"]; ?>" class="btn btn-danger btn-sm" target="_blank">PDF</a>
				</div>
			</div>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered table-hover">
					<tr>
						<th>Question</th>
						<th>Option 1</th>
						<th>Option 2</th>
						<th>Option 3</th>
						<th>Option 4</th>
						<th style="background-color: Tomato;"></th>
						<th>Your Answer</th>
						<th>Answer</th>
						<th>Result</th>
						<th>Marks</th>
					</tr>

					<?php

					$query1 = "
					SELECT * FROM question_table 
					INNER JOIN user_exam_question_answer 
					ON user_exam_question_answer.question_id = question_table.question_id 
					WHERE question_table.online_exam_id = '$exam_id' 
					AND user_exam_question_answer.user_id = '".$_SESSION["user_id"]."'
					";

					;
					
                  if($exam->user_login($query1))
                  {
                  	$total_mark = 0;
					foreach($exam->user_login_details as $value)
					{

						$option = "
						SELECT * 
						FROM option_table 
						WHERE question_id = '".$value["question_id"]."'
						";
					    $result = $exam->Data_display($option);

						 $user_answer = '';
						 $orignal_answer = '';
						 $question_result = '';

						if($value['marks'] == '0')
						{
							$question_result = '<h4 class="badge badge-dark">Not Attend</h4>';
						}

						if($value['marks'] > '0')
						{
							$question_result = '<h4 class="badge badge-success">Right</h4>';
						}

						if($value['marks'] < '0')
						{
							$question_result = '<h4 class="badge badge-danger">Wrong</h4>';
						}
                        ?>
                        <tr>
                        	<td><?php echo $value['question_title']; ?></td>



						<?php
						foreach ($result as $row)
						{?>
							
						 <td><?php echo $row['option_title'] ?></td>
                          <?php
							if($row["option_number"] == $value['user_answer_option'])
							{
								$user_answer = $row['option_title'];
							}

							if($row['option_number'] == $value['answer_option'])
							{
								$orignal_answer = $row['option_title'];
							}

						}

						?>
						<td><?php echo $user_answer; ?></td>
						<td><?php echo $orignal_answer; ?></td>
						<td><?php echo $question_result; ?></td>
						<td><?php echo $value['marks']; ?></td>
					</tr>

					   			
                  <?php
					}
                  }
                  else
                  {?>
                     <tr>
                     	<td colspan="10" class="badge-danger">Question Not Found</td>
                     </tr>
                  <?php
                  } 


					$result = "
					SELECT SUM(marks) as total_mark FROM user_exam_question_answer 
					WHERE user_id = '".$_SESSION['user_id']."' 
					AND exam_id = '".$exam_id."'
					";

				   $exam->result_display($result);

					foreach($exam->result_display as $row1)
					{
					?>
					<tr>
						<td colspan="9" align="right" style="background-color: DodgerBlue; color: white; font-size: 20px;">Total Marks</td>
						<td align="right" style="background-color: green; color: white;"><?php echo $row1["total_mark"]; ?></td>
					</tr>
					<?php	
					}

					?>
				</table>
			</div>
		</div>
	</div>
<?php
}

?>

</div>
</body>
</html>
