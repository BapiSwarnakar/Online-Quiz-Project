<?php
include_once("class/class.php");
$user = new Register_User;
$user->user_session_private();
include_once("home_header.php");
if(isset($_SESSION['user_id']))
{
	
	if ($_GET['id'])
	 {
	 	$output = "";
		if($_GET['id'] == md5(1))
		{
			$output = 1;
		}
		if($_GET['id'] == md5(2))
		{
			$output = 2;
		}
		if($_GET['id'] == md5(3))
		{
			$output = 3;
		}
		if($_GET['id'] == md5(4))
		{
			$output = 4;
		}
		echo $output;

		
	 }
}

?>