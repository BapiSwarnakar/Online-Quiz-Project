  <?php  
 include_once ('class/class.php');
 require_once('sending_mail/PHPMailerAutoload.php');
 require_once('sending_mail/class.phpmailer.php');
 $user_Reg = new Register_User;
 
date_default_timezone_set('Asia/Kolkata');
$time = date( 'h:i:s A', time () );
$date = date('d-m-Y');
$current_datetime = $date . $time;

/// THIS IS USER REGISTERED METHOD///////////////////
if(isset($_POST['action']))
{
 if($_POST['action'] =='register')
 {
            
 	        $user_verfication_code = md5(rand());

			$receiver_email = $_POST['user_email_address'];


			$arrayData =  array(
				':user_email_address'	=>	$receiver_email,
				':user_name'			=>	$_POST['user_name'],
				':user_gender'			=>	$_POST['user_gender'],
				':user_address'			=>	$_POST['user_address'],
				':user_password'		=>	password_hash($_POST['user_password'], PASSWORD_DEFAULT),
				':user_mobile_no'		=>	$_POST['user_mobile_no'],
				':user_verfication_code'=>	$user_verfication_code,
				':user_created_on'		=>	$current_datetime
				
				
			);
              
             $email = $arrayData[':user_email_address'];
             $name = $arrayData[':user_name'];
             $gender = $arrayData[':user_gender'];
             $address = $arrayData[':user_address'];
             $password = $arrayData[':user_password'];
             $mobile = $arrayData[':user_mobile_no'];
             $verification_code = $arrayData[':user_verfication_code'];
             $created = $arrayData[':user_created_on'];
             
            $check_email = "SELECT  `user_email` FROM `user_signup` WHERE user_email='$email'";
           

		    if($user_Reg->Check_Email($check_email))
		    {
		    	$output = array(
						'error'	=>"This Email Already Save our database...!"
					);
					     	
		    }
		    else
		     {
		           
            	     $subject = 'Online Quiz Registration Verification';

					 $body = '
					 <img src ="first.png" style="width:300px;height:200px">
					 <p>Hello,<b>" '.strtoupper($name).' "</b> Thankyou for registering.</p>
					 <p>This is a verification email,please click the link to verify your email address by clicking this <a href="'.$user_Reg->home_page.'verify_email.php?type=user&code='.$verification_code.'" target="_blank"><b>Link</b></a>.</p>

					 <p>Your Password is : <b>"'.$_POST['user_password'].'"</b></p>
					 <p>In case if you have any difficulty please eMail us.</p>
					 <p>Thankyou</p>
					 <p>Online Quiz System</p>';
					

			    if($user_Reg->Send_email($email,$subject,$body))
			    {
			    	 $query = "INSERT INTO `user_signup`(`user_id`, `user_email`, `user_name`, `user_gander`, `user_address`, `user_password`, `user_mobile`, `user_verification_code`, `user_created_on`, `user_image`, `user_email_verified`) 
		                     VALUES (null,'$email','$name','$gender','$address','$password','$mobile','$verification_code','$created','0','no')";
		                  if($user_Reg->User_Register($query))
                             {
				    	       $output = array(
								   'success'	=>"Please Check Your Email..!"
							    );
				    	       
				    	     }
				    	     else
				    	     {
				    	     	$output = array(
							         'error'	=> "Server Problem, Please Try Again...!"
						        );
				    	     	 
				    	     }
				    	    
			    }
			    else
			    {
			    	$output = array(
						    'error'	=> "Email is Not Sent .Please Check Your Network Connection !"
				     );
			    }
			    
			 }	
			 echo json_encode($output);
             
 }
				    	

 



/// THIS I S USER LOGIN FUNCTION METHOD////////////////////////
if($_POST['page'] == 'login')
	{
		if($_POST['action'] == 'login')
		{
            $loginData =  array(
				':user_email_address'	=>	$_POST['user_email_address'],
				':user_password'			=>	$_POST['user_password'],
				
				
				
			);
            $email_address = $loginData[':user_email_address'];
            $password = $loginData[':user_password'];
               
            $query = "SELECT * FROM `user_signup` WHERE `user_email` = '$email_address'";
            if($user_Reg->user_login($query))
            {
            	
            	foreach ($user_Reg ->user_login_details as $value) {
            		
            	}
            	if($email_address == $value['user_email'])
            	{

            		if(password_verify($password, $value['user_password'])) /// HASH PASSWORD CHECK FOR THIS METHOD
            		{
            			if($value['user_email_verified'] =='yes')
            			{
            				$_SESSION['user_id'] = $value['user_id'];
            				$output = array(
								'success'	=>	true
							);
            			}
            			else
            			{
            				$output = array(
								'error'	=>	"This Email is Not Varify...!"
							);
            				
            			}
            			
            		}
            		else
            		{
            			$output = array(
								'error'	=>"Wrong Password...!"
							);
            			
            		}
            	}
            	else
            	{
            		$output = array(
						'error'	=>	"Invalid Email Address...!"
					);
            		
            	}
            }
            else
            {
            	$output = array(
					'error'	=>	"This Email is Not Registered..!"
				);
            	
            }
          echo json_encode($output);
		}		

	}


///////////////////////  USER PROFILE CHECK OR UPDATE CODING //////////

	if($_POST['page'] == 'Profile')
	{
		if($_POST['action'] == 'Profile')
		{


			$arrayData =  array(
				':user_email_address'	=>	$_POST['user_email_address'],
				':user_name'			=>	$_POST['user_name'],
				':user_gender'			=>	$_POST['user_gender'],
				':user_address'			=>	$_POST['user_address'],
				':user_mobile_no'		=>	$_POST['user_mobile_no'],
				':Session_id'	        => $_SESSION['user_id']
				
			);
              
             $email = $arrayData[':user_email_address'];
             $name = $arrayData[':user_name'];
             $gender = $arrayData[':user_gender'];
             $address = $arrayData[':user_address'];
             $mobile = $arrayData[':user_mobile_no'];
             $user_id =$arrayData[':Session_id'];
          


             $query = "UPDATE `user_signup` SET
              `user_email`='$email',`user_name`='$name',`user_gander`='$gender',`user_address`='$address',`user_mobile`='$mobile'
               WHERE `user_id` = '$user_id'";
             if($user_Reg->User_Register($query))
             {
             	$output = array(
                   'success' => 'Update Success'
                  );
             }
             else
             {
             	$output = array(
			           'error' => 'Sever Problem'
			          );
             }

          
         echo json_encode($output);
		}

	}

////      USER PASSWORD CHANGED ////////////////////////
   
   if($_POST['page'] == 'change_password')
	{
		if($_POST['action'] == 'change_password')
		{

			$data = array(
				':user_password'	=>	password_hash($_POST['user_password'], PASSWORD_DEFAULT),
				':user_id'			=>	$_SESSION['user_id']
			);

			$password = $data[':user_password'];
			$user_id = $data[':user_id'];

             $query = "UPDATE `user_signup` SET `user_password`='$password'
               WHERE `user_id` = '$user_id'";

             if($user_Reg->User_Register($query))
             {
             	$output = array(
                   'success' => 'Password Changed done '
                  );
             }
             else
             {
             	$output = array(
			           'error' => 'Sever Problem'
			          );
             }
             
         echo json_encode($output);
		}

	}

/////////////////////    DISPLAY ENROLL TABLE SELECT METHOD (home.php) ///////////////////
 	if($_POST['page']=='home')
	{
		if($_POST['action']=='fetch_exam')
		{
			$query ="SELECT * FROM online_exam_table 
			WHERE online_exam_id = '".$_POST['exam_id']."'
			";
			if($user_Reg->Fetch_Data($query))
			{?> 

				<div class="card">
				<div class="card-header">Exam Details</div>
				<div class="card-body">
					<table class="table table-striped table-hover table-bordered">
				<?php
				foreach ($user_Reg->fetch_value as $value)
				{ ?>
                 
                 <tr>
					<td><b>Exam Title</b></td>
					<td><?php echo $value['online_exam_title']; ?></td>
				</tr>
				<tr>
					<td><b>Exam Date & Time</b></td>
					<td><?php echo $value['online_exam_datetime']; ?></td>
				</tr>
				<tr>
					<td><b>Exam Duration</b></td>
					<td><?php echo $value['online_exam_duration']; ?> Minute</td>
				</tr>
				<tr>
					<td><b>Exam Total Question</b></td>
					<td><?php echo $value['total_question'];  ?></td>
				</tr>
				<tr>
					<td><b>Marks Per Right Answer</b></td>
					<td><?php echo $value['marks_per_right_question']; ?> Mark</td>
				</tr>
				<tr>
					<td><b>Marks Per Wrong Answer</b></td>
					<td>-<?php echo $value['marks_per_wrong_question']; ?> Mark</td>
				</tr>	
				<?php
				if ($user_Reg->If_user_already_enroll_exam($_POST['exam_id'],$_SESSION['user_id']))
			    {?>
					<tr>
						<td colspan="2" align="center">
							<button type="button" name="enroll_button" class="btn btn-info">Thankyou,You are Accepted</button>
						</td>
					</tr>

				<?php
			    }
			    else
			    {?>

			    	<tr>
						<td colspan="2" align="center">
							<button type="button" name="enroll_button" id="enroll_button" class="btn btn-warning" data-exam_id="<?php echo $value['online_exam_id'] ?>">Accept Now</button>
						</td>
					</tr>

			    <?php
			     }
			    }
			    ?>
			</table>
		</div>
	</div>
			<?php
			}


		}
////////////// INSERT ENROLL DETAILS IN DATABASE / //////////////////////

		if($_POST['action']=='enroll_exam')
		 {
		  $data = array(
				':user_id'		=>	$_SESSION['user_id'],
				':exam_id'		=>	$_POST['exam_id']
			);
		    $user_id = $data[':user_id'];
		    $exam_id = $data[':exam_id'];

			$query = "INSERT INTO `user_exam_enroll_table`(`user_exam_enroll_id`, `user_id`, `exam_id`, `attendence_status`) VALUES (null,'$user_id','$exam_id','')";

			if($user_Reg->User_Register($query))
			{
				$sql ="SELECT question_id FROM question_table 
			     WHERE online_exam_id = '".$_POST['exam_id']."'";

			     if($user_Reg->Fetch_Data($sql))
			     {
			     	foreach ($user_Reg->fetch_value as $value)
			     	{
			     	  $data1 = array(
						':user_id'				=>	$_SESSION['user_id'],
						':exam_id'				=>	$_POST['exam_id'],
						':question_id'			=>	$value['question_id'],
						':user_answer_option'	=>	'0',
						':marks'				=>	'0'	
				      );
				      $user_id = $data1[':user_id'];
				      $exam_id = $data1[':exam_id'];
				      $question_id = $data1[':question_id'];
				      $user_answer_option = $data1[':user_answer_option'];
				      $marks = $data1[':marks'];

				      $query = "INSERT INTO `user_exam_question_answer`(`user_exam_question_answer_id`, 
				      `user_id`, `exam_id`, `question_id`, `user_answer_option`, `marks`)
				       VALUES (null,'$user_id','$exam_id','$question_id','$user_answer_option','$marks')";

			            $user_Reg->User_Register($query);
			            
			     	}
			    }
		    }	
	    }
    }

////////////   DISPLAY RECORD ENROLL DETAILS (enroll_exam.php)  /////////////////////

    if($_POST['page']=='enroll')
    {
    	if($_POST['action']=='enroll_fetch')
    	{
    		$query ="SELECT * FROM user_exam_enroll_table 
			INNER JOIN online_exam_table 
			ON online_exam_table.online_exam_id = user_exam_enroll_table.exam_id 
			WHERE user_exam_enroll_table.user_id = '".$_SESSION['user_id']."'";
			if($user_Reg->Fetch_Data($query))
			{
				foreach ($user_Reg->fetch_value as $value)
				{?>

			  <tr>
            	<td><?php echo $value['online_exam_title']; ?></td>
            	<td><?php echo $value['online_exam_datetime']; ?></td>
            	<td><?php echo $value['online_exam_duration']; ?> Minute</td>
            	<td><?php echo $value['total_question']; ?> Questions</td>
            	<td><?php echo $value['marks_per_right_question']; ?> Mark</td>
            	<td>-<?php echo $value['marks_per_wrong_question']; ?> Mark</td>
            	<?php  
                     
                $status = '';

				if($value['online_exam_status'] == 'Pending')
				{
					$status = '<span class="badge badge-success">Created</span>';
				}

				if($value['online_exam_status'] == 'Started')
				{
					$status = '<span class="badge badge-success">Live Started </span>';
				}

				if($value['online_exam_status'] == 'Completed')
				{
					$status = '<span class="badge badge-dark">Completed</span>';
				}
         
            	?>
            	<td><?php echo $status;  ?></td>
            	<?php 
            	 $view_exam ='';
                 if($value["online_exam_status"] == 'Started')
				{
					$view_exam = '<a href="view_exam.php?code='.$value["online_exam_code"].'" class="btn btn-info btn-sm">View Exam</a>';
				}
				if($value["online_exam_status"] == 'Completed')
				{
					$view_exam = '<a href="view_exam.php?code='.$value["online_exam_code"].'" class="btn btn-info btn-sm">View Exam</a>';
				}
            	?>
            	<td><?php echo $view_exam; ?></td>
              </tr>
				<?php
				}
			}
    		
  
    	
        }
    }



    if($_POST['page'] == 'view_exam')
	{
		if($_POST['action'] == 'load_question')
		{

 /////////////////////   FETCH ALL QUESTION & OPTION  //////////////////////
			if($_POST['question_id'] == '')
			{
				$query = "
				SELECT * FROM question_table 
				WHERE online_exam_id = '".$_POST["exam_id"]."' 
				ORDER BY question_id ASC 
				LIMIT 1
				";
			}
			else
			{
				$query = "
				SELECT * FROM question_table 
				WHERE question_id = '".$_POST["question_id"]."' 
				";
			}

			if($user_Reg->Fetch_Data($query))
			{
               
                foreach ($user_Reg->fetch_value as $value) 
                {?>

                	<h3><?php echo $value['question_title']; ?></h3>
                	<hr />
                	<br />
                	<div class="row">
                	

             <?php

		                $sql = "
						SELECT * FROM option_table 
						WHERE question_id = '".$value['question_id']."'
						";
						if($user_Reg->user_login($sql))
						{
                            $count = 1;
							foreach ($user_Reg->user_login_details as $row) 
							{?>

								<div class="col-md-6" style="margin-bottom:32px;">
								<div class="radio">
									<label><h4><input type="radio" name="option_1" class="answer_option" data-question_id="<?php echo $value['question_id'] ; ?>" data-id="<?php echo $count ; ?>"/>&nbsp;<?php echo $row["option_title"]; ?></h4></label>
								</div>
							</div>
								
							<?php
							$count = $count + 1;
						    }
						    ?>
                            </div>
						    <?php

						}

/////////////////////////  NEXT & PREVIOUS BUTTON METHOD /////////////////////////

						$query = "
						SELECT question_id FROM question_table 
						WHERE question_id < '".$value['question_id']."' 
						AND online_exam_id = '".$_POST["exam_id"]."' 
						ORDER BY question_id DESC 
						LIMIT 1";

						$user_Reg->Fetch_Data($query);

						$previous_id = '';
						$next_id = '';

						foreach($user_Reg->fetch_value as $previous_row)
						{
							$previous_id = $previous_row['question_id'];
						}

						$sql = "
						SELECT question_id FROM question_table 
						WHERE question_id > '".$value['question_id']."' 
						AND online_exam_id = '".$_POST["exam_id"]."' 
						ORDER BY question_id ASC 
						LIMIT 1";
		  				
		  				$user_Reg->user_login($sql);

		  				foreach($user_Reg->user_login_details as $next_row)
						{
							$next_id = $next_row['question_id'];
						}

						$if_previous_disable = '';
						$if_next_disable = '';

						if($previous_id == "")
						{
							$if_previous_disable = 'disabled';
						}
						
						if($next_id == "")
						{
							$if_next_disable = 'disabled';
						}?>
						<br /><br />
				  	    <div align="center">
				   		<button type="button" name="previous" class="btn btn-warning btn previous" id="<?php echo $previous_id ; ?>"<?php echo $if_previous_disable ; ?> ><< Previous</button>
				   		<button type="button" name="next" class="btn btn-success btn next" id="<?php echo $next_id ?>"<?php echo $if_next_disable ; ?> >Next >></button>
				  	</div>
				  	<br /><br />
			<?php

               }
          
			}
			
		}


  ///////////////// ALL QUESTION NAVIGATION  ///////////////////////

		if($_POST['action'] == 'question_navigation')
		{

			 $user_Reg->Check_Navigation_Button($_SESSION['user_id'],$_POST['exam_id']);
			  	$output = '
				<div class="card">
					<div class="card-header">Question Navigation</div>
					<div class="card-body">
						<div class="row">
			       ';
	              $count = 1;
		          foreach ($user_Reg->navigation_id as  $value)
		          {
		          	 //echo $value['user_answer_option'];
		          	 if($value['user_answer_option']==0)
		          	 {

		          	 	 $output .= '
						<div class="" style="margin-bottom:24px;margin-left:10px;">
							<button type="button" class="btn btn-danger question_navigation" data-question_id="'.$value["question_id"].'">'.$count.'</button>
						</div>
						';
		          	 }
		          else
		          	 {
		          	   $output .= '
						<div class="" style="margin-bottom:24px;margin-left:10px;">
							<button type="button" class="btn btn-success question_navigation" data-question_id="'.$value["question_id"].'">'.$count.'</button>
						</div>
						';
		          	 }
		         $count++;
	          }
	          $output .= '
				</div>
				</div></div>';
				echo $output;
			}

			// $query = "
			// 	SELECT question_id FROM question_table 
			// 	WHERE online_exam_id = '".$_POST["exam_id"]."' 
			// 	ORDER BY question_id ASC 
			// 	";
			// if($user_Reg->Fetch_Data($query))
			// {
				// $output = '
				// <div class="card">
				// 	<div class="card-header">Question Navigation</div>
				// 	<div class="card-body">
				// 		<div class="row">
			 //       ';
			//      $count = 1;
			//    foreach ($user_Reg->fetch_value as $value)
			//    {
			 //     $output .= '
				// <div class="" style="margin-bottom:24px;margin-left:10px;">
				// 	<button type="button" class="btn btn-danger question_navigation" data-question_id="'.$value["question_id"].'">'.$count.'</button>
				// </div>
				// ';
			// 	$count++;
			//    }
			 //   $output .= '
				// </div>
				// </div></div>
			// 	';
			//echo $output;
			//}	
			
		// }

		if($_POST['action']=='user_detail')
		{

			$query = "
			SELECT * FROM user_signup 
			WHERE user_id = '".$_SESSION["user_id"]."'
			";

			$user_Reg->Fetch_Data($query);

			$output = '
			<div class="card">
				<div class="card-header">User Details</div>
				<div class="card-body">
					<div class="row">
			';

			foreach($user_Reg->fetch_value as $row)
			{
				$output .= '
				<div class="col-md-3">
					<img src="master/user_image/'.$row["user_image"].'" class="img-fluid" />
				</div>
				<div class="col-md-9">
					<table class="table table-bordered">
						<tr>
							<th>Name</th>
							<td>'.$row["user_name"].'</td>
						</tr>
						<tr>
							<th>Email ID</th>
							<td>'.$row["user_email"].'</td>
						</tr>
						<tr>
							<th>Gendar</th>
							<td>'.$row["user_gander"].'</td>
						</tr>
					</table>
				</div>
				';
			}
			$output .= '</div></div></div>';
			echo $output;
		}

       if($_POST['action'] == 'answer')
		{

			// echo  $_POST['exam_id'];
               
            $exam_right_answer_mark = $user_Reg->Get_question_right_answer_mark($_POST['exam_id']);
            
           
			$exam_wrong_answer_mark = $user_Reg->Get_question_wrong_answer_mark($_POST['exam_id']);

			
			 $orignal_answer = $user_Reg->Get_question_answer_option($_POST['question_id']);
             // echo $exam_right_answer_mark. " wrong :".$exam_wrong_answer_mark."original :".$orignal_answer;
			$marks = 0;

			if($orignal_answer == $_POST['answer_option'])
			{
				$marks = '+' . $exam_right_answer_mark;
			}
			else
			{
				$marks = '-' . $exam_wrong_answer_mark;
			}

			$data = array(
				':user_answer_option'	=>	$_POST['answer_option'],
				':marks'				=>	$marks
			);

			$user_answer_option = $data[':user_answer_option'];
			$marks = $data[':marks'];

			$query = "
			UPDATE user_exam_question_answer 
			SET user_answer_option ='$user_answer_option', marks = '$marks' 
			WHERE user_id = '".$_SESSION["user_id"]."' 
			AND exam_id = '".$_POST['exam_id']."' 
			AND question_id = '".$_POST["question_id"]."'
			";
			$user_Reg->User_Register($query);

		}

    






    }



    

	

    

}
 ?>