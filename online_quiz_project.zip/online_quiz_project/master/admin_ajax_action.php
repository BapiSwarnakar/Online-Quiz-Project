<?php
include_once ('../class/class.php');
require_once('../sending_mail/PHPMailerAutoload.php');
require_once('../sending_mail/class.phpmailer.php');

$admin = new Register_User;

date_default_timezone_set('Asia/Kolkata');
$time = date( 'h:i:s A', time () );
$date = date('d-m-Y');
$current_datetime = $date . $time;
if(isset($_POST['page']))
{

//////////// REGISTER ADMIN CODE METHOD/////////////
		if($_POST['page'] == 'register')
		{
			if($_POST['action'] == 'register')
			{

               $user_verfication_code = md5(rand());

			$receiver_email = $_POST['user_email_address'];


			$arrayData =  array(
				':user_email_address'	=>	$receiver_email,
				':user_password'		=>	password_hash($_POST['user_password'], PASSWORD_DEFAULT),
				':user_verfication_code'=>	$user_verfication_code,
				':admin_type'		=>	'sub_master',
				':user_created_on'		=>	$current_datetime
				
				
			);
              
             $email = $arrayData[':user_email_address'];
             $password = $arrayData[':user_password'];
             $verification_code = $arrayData[':user_verfication_code'];
             $admin_type_is = $arrayData[':admin_type'];
             $created = $arrayData[':user_created_on'];
             
            $check_email = "SELECT  `admin_email_address` FROM `admin_table` WHERE `admin_email_address`='$email'";
           

		    if($admin->Check_Email($check_email))
		    {
		    	$output = array(
						'error'	=>"This Email Already Save our database...!"
					);
					     	
		    }
		    else
		     {
		           
            	     $subject = 'Online Admin Registration Verification';

					 $body = '
					 <p>Hello, Thankyou for Admin registering.</p>
					 <p>This is a verification email,please click the link to verify your email address by clicking this <a href="'.$admin->home_page.'verify_email.php?type=master&code='.$verification_code.'" target="_blank"><b>Link</b></a>.</p>

					 <p>Your Password is : <b>"'.$_POST['user_password'].'"</b></p>
					 <p>In case if you have any difficulty please eMail us.</p>
					 <p>Thankyou</p>
					 <p>Online Quiz System</p>';
					

			    if($admin->Send_email($email,$subject,$body))
			    {
			    	 $query = "INSERT INTO `admin_table`(`admin_id`, `admin_email_address`, `admin_password`, `admin_verification_code`, `admin_type`, `admin_created_on`, `email_verified`)

			    	  VALUES (null,'$email','$password','$verification_code','$admin_type_is','$created','no')";

		                  if($admin->User_Register($query))
                             {
					    	      $output = array(
									   'success'	=> "Please Check Your Email..!"
								    );
					    	       
				    	     }
				    	    else
				    	    {                           
					    	      $output = array(
									   'error'	=> "Server Down...!"
								    );
					    	       
				    	     }
				    	    
			     }
			   //  else
			   //  {
			   //  	$output = array(
						//  'error'	=> "Email is Not Sent .Please Check Your Network Connection !"
						// );
			   //  }
			    
			}	
		  echo json_encode($output);
		}
	}

// /////////////  LOGIN PAGE CODING METHOD////////////
	if($_POST['page'] == 'login')
		{
			if($_POST['action'] == 'login')
			{


              $loginData =  array(
				':user_email_address'	=>	$_POST['user_email_address'],
				':user_password'			=>	$_POST['user_password'],
				
				
				
			);
            $email_address = $loginData[':user_email_address'];
            $password = $loginData[':user_password'];
               
            $query = "SELECT * FROM `admin_table` WHERE `admin_email_address` = '$email_address'";
            if($admin->user_login($query))
            {
            	
            	foreach ($admin ->user_login_details as $value) {
            		
            	}
            	if($email_address == $value['admin_email_address'])
            	{

            		if(password_verify($password, $value['admin_password'])) /// HASH PASSWORD CHECK FOR THIS METHOD
            		{
            			if($value['email_verified'] =='yes')
            			{
            				$_SESSION['admin_id'] = $value['admin_id'];
            				$output = array(
								'success'	=>	true
							);
            			}
            			else
            			{
            				$output = array(
								'error'	=>	"This Email is Not Varify...!"
							);
            				
            			}
            			
            		}
            		else
            		{
            			$output = array(
								'error'	=>"Wrong Password...!"
							);
            			
            		}
            	}
            	else
            	{
            		$output = array(
						'error'	=>	"Invalid Email Address...!"
					);
            		
            	}
            }
            else
            {
            	$output = array(
					'error'	=>	"This Email is Not Registered..!"
				);
            	
            }
             echo json_encode($output);


			}
		}

	if($_POST['action']=='fetch')
	{
		if($_POST['page'] == 'user')
		{
			$query = "SELECT * FROM user_signup";
			if($admin->user_login($query))
            {
            	
            	foreach ($admin ->user_login_details as $value) {
                   ?>
                 <tr>
                   <td><img src="user_image/<?php echo $value['user_image']; ?>" style="border:2px solid white;width: 80px;height: 80px;"></td>
                   <td><?php echo $value['user_name']; ?></td>
                   <td><?php echo $value['user_email']; ?></td>
                   <td><?php echo $value['user_gander']; ?></td>
                   <td><?php echo $value['user_mobile']; ?></td>
                   <?php 
                      if($value['user_email_verified']=='yes')
                      { ?>
                      	<td style="text-align: center;"><span style="background-color: green;color: white; padding: 8px;"><?php echo $value['user_email_verified']; ?></span></td>
                     <?php
                      }
                      else
                      {?>
                      	<td style="text-align: center;"><span style="background-color: black;color: white;padding: 8px;"><?php echo $value['user_email_verified']; ?></span></td>
                     <?php
                      }
                   ?>
                   
                   <td><button class="btn btn-primary" onclick="View_user_details(<?php echo $value['user_id']; ?>)">View details</button></td>
               </tr>

            	<?php	
            	}
		    }
		    else
		    {
               echo '<td colspan="7"><div class="alert alert-danger">No Record Found !</div></td>';
		    }
	    }
    }

   if($_POST['action']=='view')
	{
		if($_POST['page'] == 'user_view')
		{
			$id = $_POST['view_id'];

			$query = "SELECT * FROM user_signup WHERE user_id = '$id'";
			if($admin->user_login($query))
            {
            	
            	foreach ($admin ->user_login_details as $value)
            	 {
                   
                    $is_email_verified='';
            	    if($value['user_email_verified']=='yes')
            	    {
            	    	$is_email_verified = '<label class="badge badge-success">Email Verified</label>';
            	    }
            	    else
            	    {
            	    	$is_email_verified = '<label class="badge badge-danger">Email Not Verified</label>';
            	    } 
            	 	?>
            	 	<div class="row">
					<div class="col-md-12">
						<div align="center">
							<img src="user_image/<?php echo $value['user_image']; ?>" class="img-thumbnail" width="200" />
						</div>
						<br />
						<table class="table table-bordered">
							<tr>
								<th>Name</th>
								<td><?php echo $value['user_name']; ?></td>
							</tr>
							<tr>
								<th>Gender</th>
								<td><?php echo $value['user_gander']; ?></td>
							</tr>
							<tr>
								<th>Address</th>
								<td><?php echo $value['user_address']; ?></td>
							</tr>
							<tr>
								<th>Mobile No.</th>
								<td><?php echo $value['user_mobile']; ?></td>
							</tr>
							<tr>
								<th>Email</th>
								<td><?php echo $value['user_email']; ?></td>
							</tr>
							<tr>
								<th>Email Status</th>
								<td><?php echo $is_email_verified; ?></td>
							</tr>
						</table>
					</div>
				</div>
                <?php  
                 }

            }


		}
	}

	if($_POST['page'] == 'exam')
	{
      ////   FETCH ALL QUESTION DETAILS WITH THIS CONDITION /////////////////
		if($_POST['action']=='fetch')
		{
			$query = "SELECT * FROM online_exam_table";
			if($admin->user_login($query))
            {
            	
            	foreach ($admin ->user_login_details as $value) {
                   ?>
                 <tr>
                   <td><?php echo $value['online_exam_title']; ?></td>
                   <td><?php echo $value['online_exam_datetime']; ?></td>
                   <td><?php echo $value['online_exam_duration']; ?> Minute</td>
                   <td><?php echo $value['total_question']; ?> Questions</td>
                   <td><?php echo $value['marks_per_right_question']; ?> Mark</td>
                   <td>-<?php echo $value['marks_per_wrong_question']; ?> Mark</td>
                   <?php
                       $status ='';
                      if($value['online_exam_status'] == 'Pending')
                      {
                        $status = '<span class="badge badge-warning">Pending</span>';
                      }

                      if($value['online_exam_status'] == 'Created')
                      {
                        $status = '<span class="badge badge-success">Created</span>';
                      }

                      if($value['online_exam_status'] == 'Started')
                      {
                        $status = '<span class="badge badge-success"> Live Started</span>';
                      }

                      if($value['online_exam_status'] == 'Completed')
                      {
                        $status = '<span class="badge badge-dark">Completed</span>';
                      }

                   ?>
                   <td><?php echo $status; ?></td>
                   <?php
                     if($value['online_exam_status'] == 'Completed')
                     {?>
                         <td><a href="exam_enroll.php?code=<?php echo $value['online_exam_code']; ?>" class="btn btn-secondary btn-sm">User Joint</a></td>
                     <?php
                     }
                     else
                     {?>
                       <td></td>
                     <?php
                      }
                   if($admin->Is_allowed_add_question($value['online_exam_id']))
                   {?>

                     <td><button class="btn btn-success add_question" id="<?php echo $value['online_exam_id']; ?>">Add Question</button></td>

                   <?php
                    } 
                    else
                    {?>
                       <td><a href="question.php?code=<?php echo $value['online_exam_code']; ?>" class="btn btn-warning view_question">View Question</a></td> 
                       
                    <?php
                    }

                   ?> 
                   <?php 

                    if($admin->Is_exam_is_not_started($value['online_exam_id']))
                    { ?>

                       <td>
                        <button type="button" class="btn btn-primary edit" id="<?php echo $value['online_exam_id']; ?>">Edit</button>|<button type="button" class="btn btn-primary delete" id="<?php echo $value['online_exam_id']; ?>">Delete</button>
                       </td>
                   <?php 
                   }
                   else if($value['online_exam_status'] == 'Completed')
                   {?>
                        <td><a href="exam_result_user.php?code=<?php echo $value['online_exam_code']; ?>" class="btn btn-primary" >Result</a></td>
                  <?php
                   }
                   else
                   { ?>
                      <td></td>

                  <?php
                   }
                 ?>
               </tr>
               <?php
            }
        }
        else
        {?>
        	<td colspan="10" class="alert alert-warning">Record Not Found</td>
       <?php
        }
			
            
			
	}


////////    INSERT EXAM DETAILS ////////////////////
		if ($_POST['action'] == 'Add')
		 {


		 	$data = array(
				':admin_id'				=>	$_SESSION['admin_id'],
				':online_exam_title'	=>	$admin->clean_data($_POST['online_exam_title']),
				':online_exam_datetime'	=>	$_POST['online_exam_datetime'] . ':00',
				':online_exam_duration'	=>	$_POST['online_exam_duration'],
				':total_question'		=>	$_POST['total_question'],
				':marks_per_right_answer'=>	$_POST['marks_per_right_answer'],
				':marks_per_wrong_answer'=>	$_POST['marks_per_wrong_answer'],
				':online_exam_created_on'=>	$current_datetime,
				':online_exam_status'	=>	'Pending',
				':online_exam_code'		=>	md5(rand())
			);

		   $admin_id = $data[':admin_id'];
		   $online_exam_title = $data[':online_exam_title'];
		   $online_exam_datetime = $data[':online_exam_datetime'];
		   $online_exam_duration = $data[':online_exam_duration'];
		   $total_question = $data[':total_question'];
		   $marks_per_right_answer = $data[':marks_per_right_answer'];
		   $marks_per_wrong_answer = $data[':marks_per_wrong_answer'];
		   $online_exam_created_on = $data[':online_exam_created_on'];
		   $online_exam_status = $data[':online_exam_status'];
		   $online_exam_code = $data[':online_exam_code'];

		   $query = "INSERT INTO `online_exam_table`(`online_exam_id`, `admin_id`, `online_exam_title`, `online_exam_datetime`, `online_exam_duration`, `total_question`, `marks_per_right_question`, `marks_per_wrong_question`, `online_exam_created_on`, `online_exam_status`, `online_exam_code`)

		    VALUES (null,'$admin_id','$online_exam_title','$online_exam_datetime','$online_exam_duration','$total_question','$marks_per_right_answer','$marks_per_wrong_answer','$online_exam_created_on','$online_exam_status','$online_exam_code')";
		    if($admin->User_Register($query))
		    {
		         $output = array(
                       'success' => 'Added Successfully done !'
			      );

		    }
		    else
		    {
		    	 $output = array(
                       'error' => 'Server Problem'
			      );
		    }

            echo json_encode($output);
	}
}
 ////////////////     DISPLAY EXAM DETAILS  /////////////////////// 
  if($_POST['action']=='fetch_data')
  {
     $exam_id = $_POST['exam_id'];
  	$query = "SELECT * FROM online_exam_table WHERE online_exam_id = '$exam_id'";
  	if ($admin->user_login($query))
  	 {
  		foreach ($admin->user_login_details as $value)
  		{
  			$output = array(
			     'online_exam_title'     => $value['online_exam_title'],
			     'online_exam_datetime'     => $value['online_exam_datetime'],
			     'online_exam_duration'     => $value['online_exam_duration'],
			     'total_question'     => $value['total_question'],
			     'marks_per_right_question'     => $value['marks_per_right_question'],
			     'marks_per_wrong_question'     => $value['marks_per_wrong_question']
			  	);
  		}
  	}
  	
  	echo json_encode($output);
  }

//////// /////////////// EDIT EXAM DETAILS   /////////////////////////

       if($_POST['action']=='Edit')
        {

  	        $data = array(
  	  	         'exam_id'            =>$_POST['online_exam_id'],
			     'online_exam_title'     => $_POST['online_exam_title'],
			     'online_exam_datetime'     => $_POST['online_exam_datetime'],
			     'online_exam_duration'     => $_POST['online_exam_duration'],
			     'total_question'     => $_POST['total_question'],
			     'marks_per_right_question'     => $_POST['marks_per_right_answer'],
			     'marks_per_wrong_question'     => $_POST['marks_per_wrong_answer']
			 );
  	        
  	        $exam_id = $data['exam_id'];
  	        $online_exam_title = $data['online_exam_title'];
  	        $online_exam_datetime = $data['online_exam_datetime'];
  	        $online_exam_duration = $data['online_exam_duration'];
  	        $total_question = $data['total_question'];
  	        $marks_per_right_question = $data['marks_per_right_question'];
  	        $marks_per_wrong_question = $data['marks_per_wrong_question'];

  	        $query = "UPDATE `online_exam_table` SET
  	         `online_exam_title`='$online_exam_title',
  	         `online_exam_datetime`='$online_exam_datetime',
  	         `online_exam_duration`='$online_exam_duration',
  	         `total_question`='$total_question',
  	         `marks_per_right_question`='$marks_per_right_question',
  	         `marks_per_wrong_question`='$marks_per_wrong_question' 

  	             WHERE online_exam_id = '$exam_id'";
  	             if($admin->User_Register($query))
  	             {
  	             	$output = array(
                      'success' =>'Edit Successfully done'
  	             	);
  	             }
  	             else
  	             {
  	             	$output = array(
                     'error' =>'Server Problem'
  	             	);
  	             }
  	            echo json_encode($output);
          }
/////////////////   DELETE EXAM  DETAILS  ////////////////////////////

   if($_POST['action']=='delete')
    {
    	$data = array(
           'exam_id' =>$_POST['exam_id'],
    	);

    	$exam_id = $data['exam_id'];

    	$query = "DELETE FROM `online_exam_table` WHERE online_exam_id = '$exam_id'";
    	if($admin->User_Register($query))
    	{
    		$output = array(
    			'success' => 'Delete Successfully done'

    		);
    	}
    	else
    	{
    		$output = array(
             'error' => 'Server Problem'
    		);
    	}
    	echo json_encode($output);
    }

//////////////////   QUESTION ADD METHOD /////////////////////////

    if($_POST['page'] == 'question')
    {
      if($_POST['action']=='Add')
      {


       $data = array(
        ':online_exam_id'   =>  $_POST['online_exam_id'],
        ':question_title'   =>  $admin->clean_data($_POST['question_title']),
        ':answer_option'    =>  $_POST['answer_option']
       );


      $online_exam_id = $data[':online_exam_id'];
      $question_title = $data[':question_title'];
      $answer_option = $data[':answer_option'];
 
      $query = "INSERT INTO `question_table`(`question_id`, `online_exam_id`, `question_title`, `answer_option`)
       VALUES (null,'$online_exam_id','$question_title','$answer_option')";
      if($admin->User_Register($query))
      {
         $question_id = $admin->lastid;

             for($count = 1; $count <= 4; $count++)
               {
                      $arrayData = array(
                      ':question_id'    =>  $question_id,
                      ':option_number'  =>  $count,
                      ':option_title'   =>  $admin->clean_data($_POST['option_title_' . $count])
                      );
                      $question_id = $arrayData[':question_id'];
                      $option_number = $arrayData[':option_number'];
                      $option_title = $arrayData[':option_title'];

                      $sql  = " INSERT INTO `option_table`(`option_id`, `question_id`, `option_number`, `option_title`) 
                      VALUES (null,'$question_id','$option_number','$option_title')";

                      if($admin->User_Register($sql))
                      {
                           $query = "SELECT * FROM question_table WHERE online_exam_id = '$online_exam_id'";
                           if($row = $admin->Number_of_Row($query))
                           {
                             
                            $number = "<b style='font-size:25px;'>".$row."</b>";
                            $output = array(
                                 'success'   =>  $number.' No Question Added Successfully'
                             );

                           }
                       }
             
                }
                echo json_encode($output);

          }
       

      }
    }
///////////////  QUESTION FETCH(question.php) /////////////////////////

    if($_POST['page']=='question')
    {
      if ($_POST['action']=='question_fetch')
       {
        if(isset($_POST['exam_code']))
        {
          $exam_id = $admin->Get_Exam_Id($_POST['exam_code']);
        }
        $query = "SELECT * FROM `question_table` WHERE `online_exam_id` = '$exam_id'";
        if($admin->user_login($query))
        {
          foreach ($admin->user_login_details as $value)
          {?>

            <tr>
              <td><?php echo $value['question_title']; ?></td>
              <td><?php echo "Option " .$value['answer_option']; ?></td>
             
                <?php
                if($admin->Is_exam_is_not_started($exam_id))
                { ?>
                  <td>
                    <button type="button" name="edit" class="btn btn-primary btn-sm edit" id="<?php echo $value['question_id']; ?>">Edit</button>|<button type="button" name="delete" class="btn btn-danger btn-sm delete" id="<?php echo $value['question_id']; ?>">Delete</button>
                  </td>
               <?php
                }
                ?>
              
            </tr>
            
          <?php
          }
        }

       }
    }

//////////////    QUESTION FETCH(FOR EDIT) IN MODAL (question.php)/////////////
   if($_POST['page']='question')
   {
     if ($_POST['action']=='edit_fetch')
      {

        $question_id = $_POST['question_id'];
        $query = "SELECT * FROM `question_table` WHERE `question_id`='$question_id'";
        if($admin->user_login($query))
        {
          foreach ($admin->user_login_details as $value)
          {


            $output['question_title'] = html_entity_decode($value['question_title']);
            $output['answer_option'] = $value['answer_option'];
            $output['question_id'] = $question_id;
            for($count = 1; $count <= 4; $count++)
              {
                $sql =  "SELECT `option_title` FROM `option_table` WHERE `question_id` ='$question_id'
                 AND `option_number`='".$count."'";
                 if($admin->Fetch_Data($sql))
                 {
                    foreach ($admin->fetch_value as $val)
                     {
                        $output["option_title_" . $count] = html_entity_decode($val['option_title']);
                     }
                  }

                }
           
            }
           
             echo json_encode($output);
         

         }

      }
   }

////////////////////   EDIT QUESTION METHOD   /////////////////


   if($_POST['page']=='question')
   {
    if($_POST['action']=='Edit_question')
    {

        $data = array(
          ':question_title'   =>  $_POST['question_title'],
          ':answer_option'    =>  $_POST['answer_option'],
          ':question_id'      =>  $_POST['question_id']
        );
        $question_title = $data[':question_title'];
        $answer_option = $data[':answer_option'];
        $question_id = $data[':question_id'];

        $query = "UPDATE `question_table` SET `question_title`='$question_title',`answer_option`='$answer_option'
         WHERE `question_id`='$question_id'";
         if($admin->User_Register($query))
         {

             for ($count=1; $count<=4 ; $count++)
              { 
                 $arrayData = array(
                  ':question_id'    =>  $_POST['question_id'],
                  ':option_number'  =>  $count,
                  ':option_title'   =>  $_POST['option_title_' . $count]
                );
                 $question_id = $arrayData[':question_id'];
                 $option_number = $arrayData[':option_number'];
                 $option_title  = $arrayData[':option_title'];

                $sql = "UPDATE `option_table` SET `option_title`='$option_title' 
                WHERE `question_id`='$question_id' 
                AND  `option_number`='$option_number'";

                if($admin->User_Register($sql))
                { 
                  $output = array(
                     'success' => 'Question Edit Successfully'
                    );
                }
              }
         }
     
        
      echo json_encode($output);
    }
   }


   if($_POST['page']=='question')
   {
    if ($_POST['action']=='question_delete')
     {
       $question_id = $_POST['question_id'];


       $query = "DELETE FROM question_table WHERE question_id ='$question_id'";
        if($admin->User_Register($query))
        {
          $sql = "DELETE FROM option_table WHERE question_id ='$question_id'";
          if($admin->User_Register($sql))
          {

            $output = array(
           'success' => 'Question Delete Successfully'
            );

          }

        }
       echo json_encode($output);
     }
   }



   if($_POST['action']=='enroll_fetch')
   {

       //echo  $_POST['code'];
      $exam_id = $admin->Get_exam_id($_POST['code']);
      $query = "
      SELECT * FROM user_exam_enroll_table 
      INNER JOIN user_signup 
      ON user_signup.user_id = user_exam_enroll_table.user_id  
      WHERE user_exam_enroll_table.exam_id = '".$exam_id."'
      ";

        $admin->Fetch_Data($query);
        foreach($admin->fetch_value as $row)
        {
          ?>
          <tr>
            <td><img src="user_image/<?php echo $row["user_image"] ?>" class='img-thumbnail' width='75' /></td>
            <td><?php echo $row['user_name']; ?></td>
            <td><?php echo $row['user_gander']; ?></td>
            <td><?php echo $row['user_mobile']; ?></td> 
       <?php
              $is_email_verified = '';

              if($row['user_email_verified'] == 'yes')
              {
                $is_email_verified = '<label class="badge badge-success">Yes</label>';
              }
              else
              {
                $is_email_verified = '<label class="badge badge-danger">No</label>';
              }?>
              <td><?php echo $is_email_verified; ?></td>
          <?php
              if($admin->Get_exam_status($exam_id) == 'Completed')
               {?>
               <td> <a href="user_exam_result.php?code=<?php echo $_POST['code']; ?>&id=<?php echo $row['user_id']; ?>" class="btn btn-info btn-sm" target="_blank">Result</a></td>
             </tr>
               <?php
             }
        }
     
   }

   if($_POST['action']=='fetch_result_attendense')
   {
       $exam_id = $admin->Get_exam_id($_POST["code"]);

      $query = "
      SELECT  user_signup.user_id, user_signup.user_image, user_signup.user_name, sum(user_exam_question_answer.marks) as total_mark  
      FROM user_exam_question_answer  
      INNER JOIN user_signup 
      ON user_signup.user_id = user_exam_question_answer.user_id 
      WHERE user_exam_question_answer.exam_id = '$exam_id' 
      GROUP BY user_exam_question_answer.user_id 
      ORDER BY total_mark DESC
      ";
       if($admin->Fetch_Data($query))
      {
        foreach ($admin->fetch_value as $row)
        {?>
           <tr>
             <td><img src="user_image/<?php echo $row["user_image"]; ?>" class="img-thumbnail" width="75" /></td>
             <td><?php echo $row['user_name']; ?></td>
             <td><?php echo $row['user_email']; ?></td>
             <?php 
               $status = $admin->Get_user_exam_status($exam_id,$row["user_id"]);
               ?>
             <td><?php  echo $status; ?></td>
            
             <td><?php echo $row['total_mark']; ?></td>
           </tr>
        <?php
        }

      }
      else
      {?>

        <tr>
          <td colspan="5" class="badge-danger">Record Not Found</td>
        </tr>

        <?php

      }  
     
   }

   


}
?>
