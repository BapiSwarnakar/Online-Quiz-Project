<?php
include_once("../class/class.php");
 $admin = new Register_User;
include_once("dashboard_header.php");

if(isset($_SESSION['admin_id']))
{
//echo "<script>window.location='home.php'</script>";
}
else
{
	?>
	<div class="container-fluid">
	<div align="center" style="margin-top: 5%;">
			<p><a href="admin_register.php" class="btn btn-primary btn-lg">Admin Register</a></p>
			<p><a href="index.php" class="btn btn-danger btn-lg">Admin Login</a></p>
		</div>
	<?php
}
?>