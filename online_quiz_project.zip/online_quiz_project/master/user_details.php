<?php
include_once ("../class/class.php");
$admin = new Register_User;
$admin->admin_session_private();

include_once("dashboard_header.php");

?>


<br />
<br />
<br />
<br />
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-8">
				<h3 class="panel-title">User List</h3>
			</div>
			<!-- <div class="col-md-3" align="right">
				<button type="button" id="add_button" class="btn btn-info btn-sm">Add</button>
			</div> -->
			<div style="float: right;" class="col-md-4">
			    <label>Search :</label>
			    <input type="Search" placeholder="Enter UserName or Email Address or MobileNo" name="" id="search_key" onkeyup="searchNow()" style="padding: 6px; width:400px;">
			  
		   </div>
		</div>
	</div>
	<div class="card-body">
		<span id="message_operation"></span>
		<div class="table-responsive">
			<br />
			<table class="table table-bordered table-striped table-hover" id="user_data_table">
				<thead>
					<tr>
						<th>Image</th>
						<th>User Name</th>
						<th>Email Address</th>
						<th>Gender</th>
						<th>Mobile No.</th>
						<th>Email Verified</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="user_record">
					
				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="modal" id="detailModal">
  	<div class="modal-dialog">
    	<div class="modal-content">

      		<!-- Modal Header -->
      		<div class="modal-header">
        		<h4 class="modal-title">User Details</h4>
        		<button type="button" class="close" data-dismiss="modal">&times;</button>
      		</div>

      		<!-- Modal body -->
      		<div class="modal-body" id="user_details">
        		
      		</div>

      		<!-- Modal footer -->
      		<div class="modal-footer">
        		<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      		</div>
    	</div>
  	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		DisplayData();
		//searchNow();
	});
		function DisplayData()
		{
			$.ajax({
					url : 'admin_ajax_action.php',
					type : 'post',
					data : {action :'fetch',page:'user'},
					success : function(data){
						//alert(data);
						$('#user_record').html(data);
					}
				});

		}

	 function View_user_details(id)
	 {
	 	//alert(id);
	 	$.ajax({
				url : 'admin_ajax_action.php',
				type : 'post',
				data : {action :'view',page:'user_view',view_id : id},
				success : function(data){
					//alert(data);
				$('#user_details').html(data);
				}
			 });
	 	$('#detailModal').modal('show');
	 }

	 function searchNow()
	 {
	 	let filter = document.getElementById('search_key').value.toUpperCase();

	 	let myTable = document.getElementById('user_data_table');
	 	let tr = myTable.getElementsByTagName('tr'); 

	 	for (var i = 0; i<tr.length;i++)
	 	{
	 		let td1 = tr[i].getElementsByTagName('td')[1];
	 		let td2 = tr[i].getElementsByTagName('td')[2];
	 		let td4 = tr[i].getElementsByTagName('td')[4];

	 		if(td1 || td2 || td4)
	 		{
	 			let textvalue1 = td1.textContent || td1.innerHTML;
	 			let textvalue2 = td2.textContent || td2.innerHTML;
	 			let textvalue4 = td4.textContent || td4.innerHTML;

	 			if(textvalue1.toUpperCase().indexOf(filter) > -1 || textvalue2.toUpperCase().indexOf(filter) > -1 || textvalue4.toUpperCase().indexOf(filter) > -1)
	 			{
	 				tr[i].style.display = "";
	 			}
	 			else
	 			{
	 				tr[i].style.display = "none";
	 			}
	 		}
	 	}
	}
	</script>
