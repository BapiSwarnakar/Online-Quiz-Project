<?php
include_once ("../class/class.php");
$admin = new Register_User;
$admin->admin_session_private();

include_once("dashboard_header.php");

?>
<br />
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="exam.php">Exam List</a></li>
    	<li class="breadcrumb-item active" aria-current="page">Exam Users Joint List</li>
  	</ol>
</nav>
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title">Exam Users Joint List</h3>
			</div>
			<div class="col-md-3" align="right">
				
			</div>
		</div>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="enroll_table" class="table table-bordered table-striped table-hover">
				<thead>
					<tr>
						<th>Image</th>
						<th>Name</th>
						<th>Gender</th>
						<th>Mobile No.</th>
						<th>Email Status</th>
						<th>Result</th>
					</tr>
				</thead>
				<tbody id="user_details">
					
				</tbody>
			</table>
		</div>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
	
	var code = "<?php echo $_GET['code']; ?>";
    
		$.ajax({
			url : 'admin_ajax_action.php',
			type : 'post',
			data : 
			{
				action :'enroll_fetch',
				page :'exam_enroll',
				code :code
			},
			success : function(data){
				//alert(data);
				$('#user_details').html(data);
				}
		    });
     
  
});

 

</script>

