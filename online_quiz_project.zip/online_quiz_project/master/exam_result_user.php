<?php
include_once ("../class/class.php");
$admin = new Register_User;
$admin->admin_session_private();

include_once("dashboard_header.php");

?>
<br />
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="exam.php">Exam List</a></li>
    	<li class="breadcrumb-item active" aria-current="page">Exam Result</li>
  	</ol>
</nav>
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title">Exam Result</h3>
			</div>
			<div class="col-md-3" align="right">
				<a href="pdf_exam_result.php?code=<?php echo $_GET['code']; ?>" class="btn btn-danger btn-sm" target="_blank">PDF</a>
			</div>
		</div>
	</div>
	<div class="card-body">
		<div style="float: right;">
			    <label>Search :</label>
			    <input type="Search" placeholder="Enter Email Address" name="" id="search_key" onkeyup="searchNow()" style="padding: 6px; width:300px;">
			  
		   </div>
		<div class="table-responsive">
			<br />
			<table class="table table-bordered table-striped table-hover" id="result_table">
				<thead>
					<tr>
						<th>Image</th>
						<th>User Name</th>
						<th>Email Address</th>
						<th>Attendance Status</th>
						<th>Marks</th>
					</tr>
				</thead>
				<tbody id="user_details">
					
				</tbody>
			</table>
		</div>
	</div>
</div>

<script>

$(document).ready(function(){

	var code = "<?php echo $_GET["code"];?>";
	//alert(code);
	$.ajax({
		url : "admin_ajax_action.php",
		type : "POST",
		data : 
		{
			action :"fetch_result_attendense",
		    page:"exam_result",
		    code : code
		},
		success : function(data){
			//alert(data);
			$('#user_details').html(data);
			}
	    });

});

 function searchNow()
	 {
	 	let filter = document.getElementById('search_key').value.toUpperCase();

	 	let myTable = document.getElementById('result_table');
	 	let tr = myTable.getElementsByTagName('tr'); 

	 	for (var i = 0; i<tr.length;i++)
	 	{
	 		let td1 = tr[i].getElementsByTagName('td')[2];

	 		if(td1)
	 		{
	 			let textvalue1 = td1.textContent || td1.innerHTML;
	 			

	 			if(textvalue1.toUpperCase().indexOf(filter) > -1)
	 			{
	 				tr[i].style.display = "";
	 			}
	 			else
	 			{
	 				tr[i].style.display = "none";
	 			}
	 		}
	 	}
	}

</script>