<?php
include_once ("../class/class.php");
$admin = new Register_User;
$admin->admin_session_private();

include_once("dashboard_header.php");

?>

<br />
<br />
<br/>
<br />
<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-9">
				<h3 class="panel-title">Online Exam List</h3>
			</div>
			<div class="col-md-3" align="right">
				<button type="button" id="add_button" class="btn btn-info btn-sm">Add Exam</button>
			</div>
		</div>
	</div>
	<div class="card-body">
		   <div style="float: right;">
			    <label>Search :</label>
			    <input type="search" placeholder="Enter Exam Title" name="" id="search_key" onkeyup="searchNow()">
		   </div>

		<div class="table-responsive">
      <span id="message"></span>
			<br />
			<table id="exam_data_table" class="table table-bordered table-striped table-hover">
				<thead>
					<tr>
						<th>Exam Title</th>
						<th>Date & Time</th>
						<th>Duration</th>
						<th>Total Question</th>
						<th>Right Answer Mark</th>
						<th>Wrong Answer Mark</th>
						<th>Status</th>
            <th>User Joint List</th>
						<th>Question</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="question_details">
					
				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="modal" id="formModal">
  	<div class="modal-dialog modal-lg">
    	<form method="post" id="exam_form">
      		<div class="modal-content">
      			<!-- Modal Header -->
        		<div class="modal-header">
          			<h4 class="modal-title" id="modal_title"></h4>
          			<button type="button" class="close" data-dismiss="modal">&times;</button>
        		</div>

        		<!-- Modal body -->
        		<div class="modal-body">
        			
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Exam Title <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<input type="text" name="online_exam_title" id="online_exam_title" class="form-control" />
	                			<p id="title_err"></p>
	                		</div>
            			</div>
          			</div>
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Exam Date & Time <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<input type="text" name="online_exam_datetime" id="online_exam_datetime" class="form-control" readonly />
	                			<p id="date_err"></p>
	                		</div>
            			</div>
          			</div>
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Exam Duration <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<select name="online_exam_duration" id="online_exam_duration" class="form-control">
	                				<option value="0">Select</option>
	                				<option value="5">5 Minute</option>
	                				<option value="30">30 Minute</option>
	                				<option value="60">1 Hour</option>
	                				<option value="120">2 Hour</option>
	                				<option value="180">3 Hour</option>
	                			</select>
	                			<p id="duration_err"></p>
	                		</div>
	                		
            			</div>
          			</div>
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Total Question <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<select name="total_question" id="total_question" class="form-control">
	                				<option value="0">Select</option>
	                				<option value="5">5 Question</option>
	                				<option value="10">10 Question</option>
	                				<option value="25">25 Question</option>
	                				<option value="50">50 Question</option>
	                				<option value="100">100 Question</option>
	                				<option value="200">200 Question</option>
	                				<option value="300">300 Question</option>
	                			</select>
	                			<p id="total_err"></p>
	                		</div>
	                		
            			</div>
          			</div>
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Marks for Right Answer <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<select name="marks_per_right_answer" id="marks_per_right_answer" class="form-control">
	                				<option value="0">Select</option>
	                				<option value="1">+1 Mark</option>
	                				<option value="2">+2 Mark</option>
	                				<option value="3">+3 Mark</option>
	                				<option value="4">+4 Mark</option>
	                				<option value="5">+5 Mark</option>
	                			</select>
	                			<p id="right_err"></p>
	                		</div>
	                		
            			</div>
          			</div>
          			<div class="form-group">
            			<div class="row">
              				<label class="col-md-4 text-right">Marks for Wrong Answer <span class="text-danger">*</span></label>
	              			<div class="col-md-8">
	                			<select name="marks_per_wrong_answer" id="marks_per_wrong_answer" class="form-control">
	                				<option value="0">Select</option>
	                				<option value="1">-1 Mark</option>
	                				<option value="1.25">-1.25 Mark</option>
	                				<option value="1.50">-1.50 Mark</option>
	                				<option value="2">-2 Mark</option>
	                			</select>
	                			<p id="wrong_err"></p>
	                		</div>
	                		
            			</div>
          			</div>
        		</div>

	        	<!-- Modal footer -->
	        	<div class="modal-footer">
	        		<input type="hidden" name="online_exam_id" id="online_exam_id" />

	        		<input type="hidden" name="page" value="exam" />

	        		<input type="hidden" name="action" id="action" value="Add" />

	        		<input type="submit" name="button_action" id="button_action" class="btn btn-success btn-sm" value="Add" />

	          		<button type="button" id="close_modal" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
	        	</div>
        	</div>
    	</form>
  	</div>
</div>

<!--  QUESTION MODAL  -->

<div class="modal" id="questionModal">
    <div class="modal-dialog modal-lg">
      <form method="post" id="question_form">
          <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title" id="question_modal_title"></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class="form-group">
                  <div class="row">
                      <label class="col-md-4 text-right">Question Title <span class="text-danger">*</span></label>
                      <div class="col-md-8">
                        <input type="text" name="question_title" id="question_title" autocomplete="off" class="form-control" />
                      </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                      <label class="col-md-4 text-right">Option 1 <span class="text-danger">*</span></label>
                      <div class="col-md-8">
                        <input type="text" name="option_title_1" id="option_title_1" autocomplete="off" class="form-control" />
                      </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                      <label class="col-md-4 text-right">Option 2 <span class="text-danger">*</span></label>
                      <div class="col-md-8">
                        <input type="text" name="option_title_2" id="option_title_2" autocomplete="off" class="form-control" />
                      </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                      <label class="col-md-4 text-right">Option 3 <span class="text-danger">*</span></label>
                      <div class="col-md-8">
                        <input type="text" name="option_title_3" id="option_title_3" autocomplete="off" class="form-control" />
                      </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                      <label class="col-md-4 text-right">Option 4 <span class="text-danger">*</span></label>
                      <div class="col-md-8">
                        <input type="text" name="option_title_4" id="option_title_4" autocomplete="off" class="form-control" />
                      </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                      <label class="col-md-4 text-right">Answer <span class="text-danger">*</span></label>
                      <div class="col-md-8">
                        <select name="answer_option" id="answer_option" class="form-control">
                          <option value="">Select</option>
                          <option value="1">1 Option</option>
                          <option value="2">2 Option</option>
                          <option value="3">3 Option</option>
                          <option value="4">4 Option</option>
                        </select>
                      </div>
                  </div>
                </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
              <input type="hidden" name="question_id" id="question_id" />

              <input type="hidden" name="online_exam_id" id="hidden_online_exam_id" />

              <input type="hidden" name="page" value="question" />

              <input type="hidden" name="action" id="hidden_action" value="Add" />

              <input type="submit" name="question_button_action" id="question_button_action" class="btn btn-success btn-sm" value="Add" />

                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
            </div>
          </div>
      </form>
    </div>
</div>
<script type="text/javascript">


$(document).ready(function(){

Display();
 
  function Display()
  {
	$.ajax({
		url : 'admin_ajax_action.php',
		type : 'post',
		data : {action :'fetch',page:'exam'},
		success : function(data){
			//alert(data);
			$('#question_details').html(data);
			}
	    });
   }



	$('#title_err').hide();
	$('#date_err').hide();
	$('#duration_err').hide();
	$('#total_err').hide();
	$('#right_err').hide();
	$('#wrong_err').hide();

	var date = new Date();

	date.setDate(date.getDate());

	$('#online_exam_datetime').datetimepicker({
		startDate :date,
		format: 'yyyy-mm-dd hh:ii',
		autoclose:true
	});
 ///////////// TITLE CHECK //////////////////////////////////////////////////
    $('#online_exam_title').keyup(function(){
    	var a = $('#online_exam_title').val();
    	 Title_Check(a);
    });
    function Title_Check(a)
    {
    	if(a=="")
    	{
    		$('#title_err').html("This field are required !");
    		$('#title_err').css("color","red");
    		$('#title_err').focus();
    		$('#title_err').show();
    	}
    	else
    	{
    		$('#title_err').hide();
    		return true;
    	}
    }
// /////////////// DATE TIME CHECK ////////////////////////////////
     $('#online_exam_datetime').keyup(function(){
    	var a = $('#online_exam_datetime').val();
    	 Date_Time_Check(a);
    });
    function Date_Time_Check(a)
    {
    	if(a=="")
    	{
    		$('#date_err').html("This field are required !");
    		$('#date_err').css("color","red");
    		$('#date_err').focus();
    		$('#date_err').show();
    	}
    	else
    	{
    		$('#date_err').hide();
    		return true;
    	}
    }

// /////////////// EXAM DURATION CHECK ////////////////////////////////
     $('#online_exam_duration').keyup(function(){
    	var a = $('#online_exam_duration').val();
    	 Duration_Check(a);
    });
    function Duration_Check(a)
    {
    	if(a=='0')
    	{
    		$('#duration_err').html("This field are required !");
    		$('#duration_err').css("color","red");
    		$('#duration_err').focus();
    		$('#duration_err').show();
    	}
    	else
    	{
    		$('#duration_err').hide();
    		return true;
    	}
    }
 // /////////////// TOTAL QUESTION CHECK ////////////////////////////////
     $('#total_question').keyup(function(){
    	var a = $('#total_question').val();
    	 Total_Check(a);
    });
    function Total_Check(a)
    {
    	if(a=='0')
    	{
    		$('#total_err').html("This field are required !");
    		$('#total_err').css("color","red");
    		$('#total_err').focus();
    		$('#total_err').show();
    	}
    	else
    	{
    		$('#total_err').hide();
    		return true;
    	}
    }

  // /////////////// RIGHT QUESTION CHECK ////////////////////////////////
     $('#marks_per_right_answer').keyup(function(){
    	var a = $('#marks_per_right_answer').val();
    	 Right_Check(a);
    });
    function Right_Check(a)
    {
    	if(a=='0')
    	{
    		$('#right_err').html("This field are required !");
    		$('#right_err').css("color","red");
    		$('#right_err').focus();
    		$('#right_err').show();
    	}
    	else
    	{
    		$('#right_err').hide();
    		return true;
    	}
    }
    // /////////////// WRONG QUESTION CHECK ////////////////////////////////
     $('#marks_per_wrong_answer').keyup(function(){
    	var a = $('#marks_per_wrong_answer').val();
    	 Wrong_Check(a);
    });
    function Wrong_Check(a)
    {
    	if(a=='0')
    	{
    		$('#wrong_err').html("This field are required !");
    		$('#wrong_err').css("color","red");
    		$('#wrong_err').focus();
    		$('#wrong_err').show();
    	}
    	else
    	{
    		$('#wrong_err').hide();
    		return true;
    	}
    }

function reset_form()
  {
     $('#modal_title').text('Add Exam Details');
     $('#button_action').val('Add');
     $('#action').val('Add');
     $('#exam_form')[0].reset();
    // $('#exam_form').parsley().reset();
  }



  //////    ADD RECORD  /////////////////////////////  

	$('#add_button').click(function(){
		reset_form();
		$('#formModal').modal('show');
		//$('#message_operation').html('');
      });

		$('#exam_form').on('submit',function(event){


			var title = $('#online_exam_title').val();
			var date_time = $('#online_exam_datetime').val();
			var duration = $('#online_exam_duration').val();
			var total_question = $('#total_question').val();
			var right_question = $('#marks_per_right_answer').val();
			var wrong_question = $('#marks_per_wrong_answer').val();

			Title_Check(title);
			Date_Time_Check(date_time);
			Duration_Check(duration);
			Total_Check(total_question);
			Right_Check(right_question);
			Wrong_Check(wrong_question);

           if((Title_Check(title)==true) && (Date_Time_Check(date_time)==true) && (Duration_Check(duration)==true) && (Total_Check(total_question)==true) && (Right_Check(right_question)==true) && (Wrong_Check(wrong_question)==true))
           {


           	 $.ajax({
                		url : "admin_ajax_action.php",
                		type :"post",
                		data : $('#exam_form input,select').serialize(),
                	  dataType:"json",
                	    
                		beforeSend : function(){
                			$('#button_action').val("Please Wait...");
                			$('#button_action').attr('disabled',true);
                			
                		},
                		success : function(data,status)
                		{
							    if(data.success)
                                {
                                	//alert("Your Registration Successfully Done . "+data.success);
	                            	$('#message').html('<div class="alert alert-success">'+data.success+'</div>');
	                            	// location.reload(true);
	                                $('#exam_form')[0].reset();
	                                $('#formModal').modal('hide');
	                                Display();

                                }
	                            else
	                            {
	                             	$('#message').html('<div class="alert alert-danger text-danger">'+data.error+'</div>');
	                            }
                         $('#button_action').val("Add");
                		$('#button_action').attr('disabled',false);
                		}

                	});

           }

			event.preventDefault();
	});
//////////////   EXAM QUESTION EDIT METHOD  ////////////////////

 $(document).on('click','.edit',function(){

      reset_form();

       exam_id = $(this).attr('id');

        
        $.ajax({
        url : 'admin_ajax_action.php',
        type : 'post',
        data : {action :'fetch_data',page:'exam',exam_id : exam_id},
        dataType : 'json',
        success : function(data){
              //alert(data.success);


        $('#online_exam_title').val(data.online_exam_title);

        $('#online_exam_datetime').val(data.online_exam_datetime);

        $('#online_exam_duration').val(data.online_exam_duration);

        $('#total_question').val(data.total_question);

        $('#marks_per_right_answer').val(data.marks_per_right_question);

        $('#marks_per_wrong_answer').val(data.marks_per_wrong_question);

        $('#online_exam_id').val(exam_id);

        $('#modal_title').text('Edit Exam Details');

        $('#button_action').val('Edit');

        $('#action').val('Edit');

        $('#formModal').modal('show');

         //$('#user_details').html(data);
        }
       });

    });

 //// //////  DELETE METHOD ////////////////////////

 $(document).on('click','.delete',function(event){
      
      exam_id = $(this).attr('id');
      var con = confirm("You Are Delete This Exam !");
      if(con == true)
      {

           $.ajax({
            url : 'admin_ajax_action.php',
            type : 'post',
            data : {action :'delete',page:'exam',exam_id : exam_id},
            dataType : 'json',
            success : function(data)
            {
              if(data.success)
              {

                $('#message').html('<div class="alert alert-danger">'+data.success+'</div>');
                Display();
              }
              else
              {
                $('#message').html('<div class="alert alert-danger">'+data.error+'</div>');
              }
            }

          });
        
      }


 });

 function reset_question_form()
  {
    $('#question_modal_title').text('Add Question');
    $('#question_button_action').val('Add');
    $('#hidden_action').val('Add');
    $('#question_form')[0].reset();
    $('#question_form').parsley().reset();
  }

 $(document).on('click','.add_question',function(){

      reset_question_form();

       exam_id = $(this).attr('id');
       $('#hidden_online_exam_id').val(exam_id);

      $('#questionModal').modal('show');
 });
 $('#question_form').parsley();
 $('#question_form').on('submit', function(event){
    event.preventDefault();

    $('#question_title').attr('required', 'required');

    $('#option_title_1').attr('required', 'required');

    $('#option_title_2').attr('required', 'required');

    $('#option_title_3').attr('required', 'required');

    $('#option_title_4').attr('required', 'required');

    $('#answer_option').attr('required', 'required');

    if($('#question_form').parsley().validate())
    {
      $.ajax({
        url:"admin_ajax_action.php",
        method:"POST",
        data:$(this).serialize(),
        dataType:"json",
        beforeSend:function(){
          $('#question_button_action').attr('disabled', 'disabled');

          $('#question_button_action').val('Validate...');
        },
        success:function(data)
        {
          if(data.success)
          {
            $('#message').html('<div class="alert alert-success">'+data.success+'</div>');
             reset_question_form();
             Display();
            $('#questionModal').modal('hide');
          }

          $('#question_button_action').attr('disabled', false);

          $('#question_button_action').val($('#hidden_action').val());
        }
      });
    }
  });
 




});
 function searchNow()
   {
    let filter = document.getElementById('search_key').value.toUpperCase();

    let myTable = document.getElementById('exam_data_table');
    let tr = myTable.getElementsByTagName('tr'); 

    for (var i = 0; i<tr.length;i++)
    {
      let td1 = tr[i].getElementsByTagName('td')[0];
     
      if(td1)
      {
        let textvalue1 = td1.textContent || td1.innerHTML;

        if(textvalue1.toUpperCase().indexOf(filter) > -1)
        {
          tr[i].style.display = "";
        }
        else
        {
          tr[i].style.display = "none";
        }
      }
    }
  }
</script>

